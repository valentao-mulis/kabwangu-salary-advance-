
export const logVisitorEvent = (action: string, details: string = '') => {
    try {
        // Persistent ID for the device
        let visitorId = localStorage.getItem('xtenda_visitor_id');
        if (!visitorId) {
             visitorId = 'v_' + Math.random().toString(36).substr(2, 9);
             localStorage.setItem('xtenda_visitor_id', visitorId);
        }

        // Session ID for the current tab/window session
        let sessionId = sessionStorage.getItem('xtenda_session_id');
         if (!sessionId) {
            sessionId = 's_' + Date.now().toString(36);
            sessionStorage.setItem('xtenda_session_id', sessionId);
        }

        const entry = {
            id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
            timestamp: new Date().toISOString(),
            visitorId,
            sessionId,
            action,
            details
        };

        const logs = JSON.parse(localStorage.getItem('xtenda_activity_logs') || '[]');
        logs.unshift(entry);
        // Keep last 1000 events to prevent storage issues
        if (logs.length > 1000) logs.length = 1000;
        
        localStorage.setItem('xtenda_activity_logs', JSON.stringify(logs));
    } catch (e) {
        console.warn("Activity logging failed:", e);
    }
};
