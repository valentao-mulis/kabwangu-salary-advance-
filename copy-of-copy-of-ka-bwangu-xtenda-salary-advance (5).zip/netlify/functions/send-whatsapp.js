
// This function sends a WhatsApp message using the Twilio API.
// It's designed to be deployed as a Netlify serverless function.
//
// To make this work, you must set the following environment variables in
// your Netlify project dashboard:
// - TWILIO_ACCOUNT_SID: Your Twilio Account SID
// - TWILIO_AUTH_TOKEN: Your Twilio Auth Token
// - TWILIO_WHATSAPP_FROM: Your Twilio WhatsApp-enabled phone number (e.g., whatsapp:+14155238886)
// - ADMIN_WHATSAPP_TO: The admin's WhatsApp number to receive notifications (e.g., whatsapp:+260...)

exports.handler = async function(event) {
  // Only accept POST requests
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const application = JSON.parse(event.body);

    const {
      TWILIO_ACCOUNT_SID,
      TWILIO_AUTH_TOKEN,
      TWILIO_WHATSAPP_FROM,
      ADMIN_WHATSAPP_TO
    } = process.env;

    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_WHATSAPP_FROM || !ADMIN_WHATSAPP_TO) {
        console.error("Missing Twilio environment variables on the server.");
        return {
            statusCode: 500,
            body: "Server configuration error: Missing required environment variables for WhatsApp notifications."
        };
    }
    
    // Helper to format currency values
    const formatCurrency = (amount) => {
        // Default to 0 if amount is not a valid number
        const num = Number(amount) || 0;
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ZMW', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(num);
    }

    // Construct the message body with WhatsApp markdown
    const messageBody = `*New Xtenda Salary Advance Application!* 📝\n\n` +
        `*Name:* ${application.fullNames}\n` +
        `*Phone:* ${application.phone}\n` +
        `*NRC:* ${application.nrc}\n` +
        `*Employer:* ${application.employer}\n` +
        `*Net Salary:* ${formatCurrency(application.netSalary)}\n\n` +
        `*Loan Amount:* ${formatCurrency(application.loanDetails?.amount)}\n` +
        `*Tenure:* ${application.loanDetails?.months} Months\n\n` +
        `*Status:* ${application.status}\n` +
        `*Submitted:* ${new Date(application.submittedAt).toLocaleString('en-GB')}`;

    const endpoint = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;
    
    // Twilio requires a URL-encoded form body
    const encodedBody = new URLSearchParams();
    encodedBody.append('To', ADMIN_WHATSAPP_TO);
    encodedBody.append('From', TWILIO_WHATSAPP_FROM);
    encodedBody.append('Body', messageBody);

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: encodedBody.toString()
    });

    const responseData = await response.json();
    
    if (!response.ok) {
        console.error("Twilio API Error:", responseData);
        throw new Error(`Twilio API responded with status ${response.status}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'WhatsApp notification sent successfully.', sid: responseData.sid })
    };

  } catch (error) {
    console.error('Error in send-whatsapp function:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to send WhatsApp notification.' })
    };
  }
};
