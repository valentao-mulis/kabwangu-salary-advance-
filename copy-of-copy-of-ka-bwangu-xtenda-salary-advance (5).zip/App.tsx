
import React from 'react';
import Header from './components/Header';
import HowItWorks from './components/HowItWorks';
import SalaryCalculator from './components/SalaryCalculator';
import ApplicationForm from './components/ApplicationForm';
import ContactButtons from './components/ContactButtons';
import Footer from './components/Footer';
import AdminView from './components/AdminView';
import AdminDashboard from './components/AdminDashboard';
import Chatbot from './components/Chatbot';
import InstallPrompt from './components/InstallPrompt';
import BenefitsSection from './components/BenefitsSection';
import { logVisitorEvent } from './utils';

declare var pako: any;

type PageView = 'home' | 'apply' | 'contact';
type ViewState = PageView | 'admin_dashboard' | 'admin_view_application' | 'admin_login';

const App = () => {
  const [isAdmin, setIsAdmin] = React.useState(false);
  const [currentView, setCurrentView] = React.useState<ViewState>('home');
  const [selectedApplication, setSelectedApplication] = React.useState(null);
  // Lifted state for loan details to share between Calculator and Application Form
  const [loanSummary, setLoanSummary] = React.useState({ amount: 0, months: 0, monthlyPayment: 0 });
  
  // Admin Login state
  const [adminPassword, setAdminPassword] = React.useState('');
  const [loginError, setLoginError] = React.useState('');

  React.useEffect(() => {
    // Log initial visit
    logVisitorEvent('VISIT', 'App loaded');

    const processHashData = () => {
        const hash = window.location.hash;
        if (hash && hash.length > 1) {
            // Legacy support for hash-based links if needed
            let viewData = hash.substring(1);
            try {
                viewData = viewData.replace(/-/g, '+').replace(/_/g, '/');
                const binaryString = atob(viewData);
                const len = binaryString.length;
                const bytes = new Uint8Array(len);
                for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
                const jsonString = pako.inflate(bytes, { to: 'string' });
                const data = JSON.parse(jsonString);
                setSelectedApplication(data);
                // Bypass login for direct hash links if desired, or force login here too. 
                // For now, sticking to original behavior for shared links, but could be changed to 'admin_login'
                setCurrentView('admin_view_application');
                setIsAdmin(true);
                logVisitorEvent('ADMIN_ACCESS', 'Accessed via shared link');
                // Clean URL
                window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
            } catch (error) {
                console.error("Failed to parse application data from hash:", error);
                window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
            }
        }
    };
    processHashData();
    window.addEventListener('hashchange', processHashData, false);
    return () => window.removeEventListener('hashchange', processHashData, false);
  }, []);

  const handleAdminToggle = () => {
      // Go to login instead of direct dashboard
      setCurrentView('admin_login');
      setAdminPassword('');
      setLoginError('');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (adminPassword === '8253') {
          setIsAdmin(true);
          setCurrentView('admin_dashboard');
          logVisitorEvent('ADMIN_ACCESS', 'Admin Logged In');
      } else {
          setLoginError('Incorrect password');
          logVisitorEvent('ADMIN_FAILED', 'Failed login attempt');
      }
  };

  const handleExitAdmin = () => {
      setIsAdmin(false);
      setCurrentView('home');
      setSelectedApplication(null);
      logVisitorEvent('ADMIN_ACTION', 'Exited Admin Mode');
  };

  // Exact schedule from "Ka Bwangu" flyer
  const initialSchedule = [
    { disbursedAmount: 500, installments: { 1: 664, 2: 357, 3: 243, 4: 194, 5: 161, 6: 189 } },
    { disbursedAmount: 600, installments: { 1: 780, 2: 420, 3: 285, 4: 228, 5: 189, 6: 213 } },
    { disbursedAmount: 700, installments: { 1: 896, 2: 472, 3: 328, 4: 261, 5: 217, 6: 237 } },
    { disbursedAmount: 800, installments: { 1: 1012, 2: 533, 3: 370, 4: 295, 5: 245, 6: 262 } },
    { disbursedAmount: 900, installments: { 1: 1129, 2: 594, 3: 412, 4: 329, 5: 273, 6: 286 } },
    { disbursedAmount: 1000, installments: { 1: 1245, 2: 665, 3: 455, 4: 363, 5: 301, 6: 310 } },
    { disbursedAmount: 1500, installments: { 1: 1825, 2: 961, 3: 667, 4: 533, 5: 442, 6: 431 } },
    { disbursedAmount: 2000, installments: { 1: 2406, 2: 1266, 3: 879, 4: 702, 5: 582, 6: 552 } },
    { disbursedAmount: 2500, installments: { 1: 2986, 2: 1572, 3: 1091, 4: 872, 5: 723, 6: 673 } },
    { disbursedAmount: 3000, installments: { 1: 3567, 2: 1878, 3: 1303, 4: 1041, 5: 863, 6: 795 } },
    { disbursedAmount: 3500, installments: { 1: 4147, 2: 2183, 3: 1515, 4: 1211, 5: 1004, 6: 916 } },
    { disbursedAmount: 4000, installments: { 1: 4728, 2: 2489, 3: 1728, 4: 1380, 5: 1145, 6: 1037 } },
    { disbursedAmount: 4500, installments: { 1: 5309, 2: 2794, 3: 1940, 4: 1550, 5: 1285, 6: 1158 } },
    { disbursedAmount: 5000, installments: { 1: 5889, 2: 3100, 3: 2152, 4: 1719, 5: 1426, 6: 1279 } },
    { disbursedAmount: 5500, installments: { 1: 6470, 2: 3406, 3: 2364, 4: 1889, 5: 1566, 6: 1400 } },
    { disbursedAmount: 6000, installments: { 1: 7050, 2: 3711, 3: 2579, 4: 2059, 5: 1707, 6: 1521 } },
    { disbursedAmount: 6500, installments: { 1: 7634, 2: 4024, 3: 2792, 4: 2228, 5: 1848, 6: 1642 } },
    { disbursedAmount: 7000, installments: { 1: 8215, 2: 4329, 3: 3004, 4: 2398, 5: 1988, 6: 1764 } },
    { disbursedAmount: 7500, installments: { 1: 8796, 2: 4636, 3: 3216, 4: 2567, 5: 2129, 6: 1885 } },
    { disbursedAmount: 8000, installments: { 1: 9377, 2: 4942, 3: 3429, 4: 2737, 5: 2269, 6: 2006 } },
    { disbursedAmount: 8500, installments: { 1: 9958, 2: 5248, 3: 3641, 4: 2906, 5: 2410, 6: 2127 } },
    { disbursedAmount: 9000, installments: { 1: 10538, 2: 5554, 3: 3854, 4: 3064, 5: 2541, 6: 2248 } },
    { disbursedAmount: 9500, installments: { 1: 11119, 2: 5860, 3: 4066, 4: 3233, 5: 2681, 6: 2369 } },
    { disbursedAmount: 10000, installments: { 1: 11700, 2: 6166, 3: 4278, 4: 3402, 5: 2821, 6: 2490 } }
  ];

  const [schedule, setSchedule] = React.useState(() => {
    // Prioritize the hardcoded initialSchedule to ensure it matches the flyer requested.
    return initialSchedule;
  });

  const handleScheduleChange = (newSchedule: any) => {
    setSchedule(newSchedule);
    // Optional: re-enable local storage saving if dynamic admin edits are needed later
    // localStorage.setItem('xtenda_schedule', JSON.stringify(newSchedule));
  };

  const navigateTo = (view: PageView) => {
      if (currentView !== view) {
          logVisitorEvent('NAVIGATION', `Visited ${view.charAt(0).toUpperCase() + view.slice(1)} Page`);
      }
      setCurrentView(view);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderContent = () => {
      if (currentView === 'admin_login') {
          return (
             <div className="min-h-[50vh] flex items-center justify-center">
                 <form onSubmit={handleLoginSubmit} className="bg-white p-8 rounded-xl shadow-xl max-w-sm w-full">
                     <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Admin Access</h2>
                     <input 
                        type="password" 
                        value={adminPassword} 
                        onChange={(e) => setAdminPassword(e.target.value)}
                        placeholder="Enter admin password"
                        className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:ring-2 focus:ring-orange-500"
                        autoFocus
                     />
                     {loginError && <p className="text-red-500 text-sm mb-4 font-medium text-center">{loginError}</p>}
                     <div className="flex gap-3">
                         <button type="button" onClick={() => setCurrentView('home')} className="flex-1 py-3 text-gray-600 font-bold hover:bg-gray-100 rounded-lg transition">Cancel</button>
                         <button type="submit" className="flex-1 bg-orange-500 text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition">Login</button>
                     </div>
                 </form>
             </div>
          );
      }

      if (isAdmin) {
          if (currentView === 'admin_dashboard') {
              return <AdminDashboard onSelectApplication={(app) => { setSelectedApplication(app); setCurrentView('admin_view_application'); }} onExitAdmin={handleExitAdmin} />;
          } else if (currentView === 'admin_view_application' && selectedApplication) {
              return <AdminView data={selectedApplication} onBack={() => setCurrentView('admin_dashboard')} />;
          }
      }

      switch (currentView) {
          case 'apply':
              return <ApplicationForm loanSummary={loanSummary} />;
          case 'contact':
              return <ContactButtons />;
          case 'home':
          default:
              return (
                  <>
                      <section className="text-center mt-12 mb-8 px-4 animate-fade-in">
                        <h2 className="text-4xl md:text-5xl font-extrabold text-green-700 leading-tight mb-6">
                          Need Cash? Get a <span className="text-orange-500">Ka Bwangu Bwangu</span> Salary Advance!
                        </h2>
                        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                          Flexible repayments, competitive rates, and instant disbursement to your account.
                        </p>
                      </section>

                      <BenefitsSection />

                      <HowItWorks onNavigate={navigateTo} />
                      
                      <div className="text-center my-10 animate-fade-in">
                        <button 
                            onClick={() => navigateTo('apply')}
                            className="bg-green-600 text-white font-bold py-4 px-12 rounded-full hover:bg-green-700 transition duration-300 text-lg shadow-xl transform hover:scale-105 flex items-center gap-3 mx-auto"
                        >
                          Apply Now <i className="fa-solid fa-arrow-right"></i>
                        </button>
                      </div>

                      <SalaryCalculator 
                          schedule={schedule} 
                          isAdmin={isAdmin} 
                          onScheduleChange={handleScheduleChange}
                          onLoanChange={setLoanSummary}
                          onNavigate={navigateTo}
                      />
                  </>
              );
      }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-gradient-to-br from-orange-50 to-green-50">
      {!isAdmin && currentView !== 'admin_login' && <Header onNavigate={navigateTo} currentView={currentView as PageView} onAdminToggle={handleAdminToggle} />}
      
      <main className={`flex-grow container mx-auto px-4 ${!isAdmin ? 'py-8' : ''}`}>
        {renderContent()}
      </main>

      {!isAdmin && currentView !== 'admin_login' && <Footer onAdminToggle={handleAdminToggle} />}
      
      {!isAdmin && currentView !== 'admin_login' && <Chatbot schedule={schedule} />}
      <InstallPrompt />
      <style>{`
        .animate-fade-in { animation: fadeIn 0.8s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};

export default App;
