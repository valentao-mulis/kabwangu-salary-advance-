
import React from 'react';
import { ActivityLogEntry } from '../types';

interface AdminDashboardProps {
    onSelectApplication: (app: any) => void;
    onExitAdmin: () => void;
}

type DashboardTab = 'applications' | 'logs';

const AdminDashboard = ({ onSelectApplication, onExitAdmin }: AdminDashboardProps) => {
  const [applications, setApplications] = React.useState<any[]>([]);
  const [logs, setLogs] = React.useState<ActivityLogEntry[]>([]);
  const [activeTab, setActiveTab] = React.useState<DashboardTab>('applications');

  React.useEffect(() => {
    loadData();
    
    // Listen for changes to localStorage from other tabs/windows to update immediately
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'xtenda_applications' || e.key === 'xtenda_activity_logs') {
            loadData();
        }
    };

    // Also reload when the window comes back into focus to be extra sure on mobile devices
    const handleFocus = () => {
        loadData();
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('focus', handleFocus);
    return () => {
        window.removeEventListener('storage', handleStorageChange);
        window.removeEventListener('focus', handleFocus);
    };
  }, []);

  const loadData = () => {
    try {
        // Load Applications
        const appData = localStorage.getItem('xtenda_applications');
        if (appData) {
            const parsedApps = JSON.parse(appData);
            parsedApps.sort((a: any, b: any) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
            setApplications(parsedApps);
        }
        // Load Logs
        const logData = localStorage.getItem('xtenda_activity_logs');
        if (logData) {
            setLogs(JSON.parse(logData));
        }
    } catch (error) {
        console.error("Error loading admin data:", error);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (window.confirm("Are you sure you want to delete this application? This cannot be undone.")) {
          const updatedApps = applications.filter(app => app.id !== id);
          setApplications(updatedApps);
          localStorage.setItem('xtenda_applications', JSON.stringify(updatedApps));
      }
  };

  const clearLogs = () => {
      if(window.confirm("Clear all activity logs?")) {
          localStorage.removeItem('xtenda_activity_logs');
          setLogs([]);
      }
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8 font-sans">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-col md:flex-row justify-between items-center mb-8 bg-white p-6 rounded-xl shadow-md gap-4">
            <div>
                <div className="flex items-center gap-3">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
                        <span className="text-orange-500">Xtenda</span> Admin Dashboard
                    </h1>
                    <div className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full flex items-center gap-1 font-medium" title="This dashboard only shows data saved on THIS specific device's browser storage.">
                        <i className="fa-solid fa-hard-drive"></i>
                        <span>Local Device Data Only</span>
                    </div>
                </div>
                <p className="text-gray-500 mt-1">Overview of system activity on this device</p>
            </div>
            <button 
                onClick={onExitAdmin} 
                className="bg-gray-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-700 transition flex items-center gap-2"
            >
                <i className="fa-solid fa-right-from-bracket"></i> Exit
            </button>
        </header>

        {/* Tabs */}
        <div className="flex mb-6 bg-white rounded-lg shadow p-1 w-fit">
            <button 
                onClick={() => setActiveTab('applications')}
                className={`px-6 py-3 rounded-md font-bold transition ${activeTab === 'applications' ? 'bg-orange-500 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}
            >
                <i className="fa-solid fa-file-invoice mr-2"></i> Applications
            </button>
            <button 
                 onClick={() => { setActiveTab('logs'); loadData(); }}
                className={`px-6 py-3 rounded-md font-bold transition ${activeTab === 'logs' ? 'bg-orange-500 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'}`}
            >
                <i className="fa-solid fa-shoe-prints mr-2"></i> Activity Logs
            </button>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            
            {/* Applications Tab */}
            {activeTab === 'applications' && (
                <>
                    <div className="p-6 border-b flex justify-between items-center bg-gray-50">
                        <h2 className="text-xl font-bold text-gray-700">Submitted Applications ({applications.length})</h2>
                        <button onClick={loadData} className="text-blue-600 hover:text-blue-800 transition flex items-center gap-1" title="Refresh List">
                            <i className="fa-solid fa-sync"></i> Refresh
                        </button>
                    </div>
                    
                    {applications.length === 0 ? (
                        <div className="p-12 text-center text-gray-500">
                            <i className="fa-solid fa-inbox fa-4x mb-4 text-gray-300"></i>
                            <p className="text-xl">No applications received yet on this device.</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className="bg-gray-100 border-b">
                                    <tr>
                                        <th className="px-6 py-4 font-semibold text-gray-600">Date</th>
                                        <th className="px-6 py-4 font-semibold text-gray-600">Applicant Name</th>
                                        <th className="px-6 py-4 font-semibold text-gray-600 hidden md:table-cell">Employer</th>
                                        <th className="px-6 py-4 font-semibold text-gray-600 hidden sm:table-cell">Phone</th>
                                        <th className="px-6 py-4 font-semibold text-gray-600 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {applications.map((app) => (
                                        <tr 
                                            key={app.id} 
                                            onClick={() => onSelectApplication(app)}
                                            className="hover:bg-orange-50 cursor-pointer transition"
                                        >
                                            <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                                                {new Date(app.submittedAt).toLocaleDateString()} <br/>
                                                <span className="text-xs text-gray-500">{new Date(app.submittedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                            </td>
                                            <td className="px-6 py-4 font-medium text-gray-900">{app.fullNames}</td>
                                            <td className="px-6 py-4 text-gray-600 hidden md:table-cell">{app.employer}</td>
                                            <td className="px-6 py-4 text-gray-600 hidden sm:table-cell">{app.phone}</td>
                                            <td className="px-6 py-4 text-right space-x-3">
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); onSelectApplication(app); }} 
                                                    className="text-blue-600 hover:text-blue-800 font-semibold text-sm"
                                                >
                                                    View
                                                </button>
                                                <button 
                                                    onClick={(e) => handleDelete(app.id, e)} 
                                                    className="text-red-500 hover:text-red-700"
                                                    title="Delete Application"
                                                >
                                                    <i className="fa-solid fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </>
            )}

            {/* Activity Logs Tab */}
            {activeTab === 'logs' && (
                <>
                    <div className="p-6 border-b flex justify-between items-center bg-gray-50">
                        <h2 className="text-xl font-bold text-gray-700">Visitor Activity Logs ({logs.length})</h2>
                        <div className="flex gap-4">
                            <button onClick={clearLogs} className="text-red-500 hover:text-red-700 transition flex items-center gap-1 text-sm">
                                <i className="fa-solid fa-trash-can"></i> Clear Logs
                            </button>
                             <button onClick={loadData} className="text-blue-600 hover:text-blue-800 transition flex items-center gap-1 text-sm">
                                <i className="fa-solid fa-sync"></i> Refresh
                            </button>
                        </div>
                    </div>

                     {logs.length === 0 ? (
                        <div className="p-12 text-center text-gray-500">
                            <p>No activity recorded yet on this device.</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-gray-100 border-b sticky top-0 shadow-sm">
                                    <tr>
                                        <th className="px-4 py-3 font-semibold text-gray-600">Time</th>
                                        <th className="px-4 py-3 font-semibold text-gray-600">Action</th>
                                        <th className="px-4 py-3 font-semibold text-gray-600">Details</th>
                                        <th className="px-4 py-3 font-semibold text-gray-600 text-xs">Visitor ID</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {logs.map((log) => (
                                        <tr key={log.id} className="hover:bg-gray-50">
                                            <td className="px-4 py-2 whitespace-nowrap text-gray-600">
                                                {new Date(log.timestamp).toLocaleString()}
                                            </td>
                                            <td className="px-4 py-2 font-medium">
                                                <span className={`px-2 py-1 rounded-full text-xs font-bold 
                                                    ${log.action === 'NAVIGATION' ? 'bg-blue-100 text-blue-800' : 
                                                      log.action === 'INTEREST' ? 'bg-green-100 text-green-800' : 
                                                      log.action === 'SUBMISSION' ? 'bg-purple-100 text-purple-800' : 
                                                      'bg-gray-100 text-gray-800'}`}>
                                                    {log.action}
                                                </span>
                                            </td>
                                            <td className="px-4 py-2 text-gray-800">{log.details}</td>
                                            <td className="px-4 py-2 text-gray-400 text-xs font-mono">{log.visitorId.substring(0, 8)}...</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                     )}
                </>
            )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
