
import React from 'react';
import AdminChatbot from './AdminChatbot';

// Ensure jsPDF is available globally from the CDN script in index.html
declare var jspdf: any;

interface AdminViewProps {
    data: any;
    onBack?: () => void;
}

const AdminView = ({ data, onBack }: AdminViewProps) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editableData, setEditableData] = React.useState(data);
  const [saveMessage, setSaveMessage] = React.useState<{text: string, type: 'success'|'error'|'pending'} | null>(null);
  const [errors, setErrors] = React.useState<{[key: string]: string}>({});
  const [notifySMS, setNotifySMS] = React.useState(false);

  // Update local state when data prop changes (e.g. when switching between apps)
  React.useEffect(() => {
      setEditableData(data);
      setIsEditing(false);
      setSaveMessage(null);
      setErrors({});
      setNotifySMS(false);
  }, [data]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditableData((prev: any) => ({ ...prev, [name]: value }));
    // Clear error for this field when edited
    if (errors[name]) {
        setErrors(prev => {
            const newErrors = { ...prev };
            delete newErrors[name];
            return newErrors;
        });
    }
  };

  const validate = () => {
      const newErrors: {[key: string]: string} = {};
      
      if (!editableData.fullNames?.trim()) newErrors.fullNames = "Full Name is required.";
      
      if (!editableData.nrc?.trim()) {
          newErrors.nrc = "NRC is required.";
      } else {
           // Basic loosely strict check: at least 9 digits, allows typical separators like / or -
           const nrcDigits = editableData.nrc.replace(/\D/g, '');
           if (nrcDigits.length < 9) newErrors.nrc = "Invalid NRC format (too short).";
      }

      if (!editableData.phone?.trim()) {
          newErrors.phone = "Phone is required.";
      } else {
          // Must have at least 10 digits
          if (editableData.phone.replace(/\D/g,'').length < 10) newErrors.phone = "Phone must have at least 10 digits.";
      }

      if (!editableData.email?.trim()) {
           newErrors.email = "Email is required.";
      } else if (!/\S+@\S+\.\S+/.test(editableData.email)) {
           newErrors.email = "Invalid email address format.";
      }

      if (!editableData.employer?.trim()) newErrors.employer = "Employer is required.";

      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const mockSendSMS = async (phone: string, message: string) => {
      console.log(`[SMS SERVICE MOCK] Sending to ${phone}: ${message}`);
      // Simulate network delay for realistic UI
      await new Promise(resolve => setTimeout(resolve, 2000));
      return true;
  };

  const handleSave = async () => {
      if (!validate()) {
          setSaveMessage({ text: "Please fix validation errors before saving.", type: 'error' });
          setTimeout(() => setSaveMessage((prev) => prev?.type === 'error' ? null : prev), 3000);
          return;
      }

      try {
          const existingData = localStorage.getItem('xtenda_applications');
          if (existingData) {
              let applications = JSON.parse(existingData);
              const index = applications.findIndex((app: any) => app.id === editableData.id);
              
              if (index !== -1) {
                  applications[index] = editableData;
                  localStorage.setItem('xtenda_applications', JSON.stringify(applications));
                  
                  if (notifySMS) {
                      setSaveMessage({ text: "Saving changes and sending SMS...", type: 'pending' });
                      
                      const firstName = editableData.fullNames.split(' ')[0] || 'Client';
                      let smsMessage = "";
                      switch(editableData.status) {
                           case 'Approved': 
                               smsMessage = `Good news ${firstName}! Your Xtenda loan is APPROVED. Funds will be disbursed shortly.`; 
                               break;
                           case 'Rejected': 
                               smsMessage = `Dear ${firstName}, unfortunately your Xtenda loan application was not successful at this time.`; 
                               break;
                           case 'Reviewing': 
                               smsMessage = `Dear ${firstName}, your Xtenda loan application is currently being reviewed by our team.`; 
                               break;
                           case 'Pending': 
                               smsMessage = `Dear ${firstName}, your Xtenda application is pending. We may need more information from you.`; 
                               break;
                           default: 
                               smsMessage = `Dear ${firstName}, the status of your Xtenda loan application is now: ${editableData.status}.`;
                      }

                      await mockSendSMS(editableData.phone, smsMessage);
                      setSaveMessage({ text: `Application saved & SMS sent to ${editableData.phone}.`, type: 'success' });
                  } else {
                      setSaveMessage({ text: "Application updated successfully.", type: 'success' });
                  }
                  
                  setIsEditing(false);
                  // Clear success message after 4 seconds
                  setTimeout(() => setSaveMessage(null), 4000);
              } else {
                  throw new Error("Application not found in storage.");
              }
          } else {
               throw new Error("No local storage data found.");
          }
      } catch (error) {
          console.error("Failed to save application:", error);
          setSaveMessage({ text: "Failed to save changes. Please try again.", type: 'error' });
      }
  };
  
  const handleCancel = () => {
    setEditableData(data); // Revert to original data
    setIsEditing(false);
    setSaveMessage(null);
    setErrors({});
    setNotifySMS(false);
  };

  const handleEmailApplicant = () => {
    const { fullNames, email, status, loanDetails } = editableData;
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
        alert("Applicant does not have a valid email address.");
        return;
    }

    const firstName = fullNames.split(' ')[0] || 'Applicant';
    let subject = `Update on your Xtenda Loan Application`;
    let body = `Dear ${firstName},\n\n`;

    switch (status) {
        case 'Approved':
            const amount = loanDetails?.amount ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ZMW', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(loanDetails.amount) : '[Loan Amount]';
            subject = `Congratulations! Your Xtenda Loan Application is Approved!`;
            body += `We are pleased to inform you that your salary advance application for ${amount} has been approved.\n\nThe funds will be disbursed to your provided bank account shortly.\n\nThank you for choosing Xtenda.`;
            break;
        case 'Rejected':
            subject = `Update on your Xtenda Loan Application`;
            body += `We regret to inform you that after careful consideration, we are unable to approve your salary advance application at this time.\n\nWe encourage you to reapply in the future should your circumstances change.\n\nThank you for your interest in Xtenda.`;
            break;
        case 'Pending':
            subject = `Action Required for your Xtenda Loan Application`;
            body += `Your salary advance application is currently pending as it requires additional information from you.\n\nPlease contact us at your earliest convenience to provide the necessary details so we can continue processing your application.\n\nOur contact number is +260 774 219 397.`;
            break;
        case 'Reviewing':
            body += `This is a confirmation that your salary advance application is currently under review by our team.\n\nWe will notify you of the outcome as soon as the review process is complete.\n\nThank you for your patience.`;
            break;
        default: // 'New' or any other status
            body += `We are reviewing your application for a salary advance.\n\nWe will be in touch shortly with an update.`;
            break;
    }

    body += `\n\nKind regards,\nThe Xtenda Team\ninfo@xtenda.co.zm`;

    const mailtoLink = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
  };

  const generatePDF = () => {
    if (!jspdf) {
        alert("PDF generation library not loaded.");
        return;
    }
    const { jsPDF } = jspdf;
    const doc = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' }); // A4 is 210mm x 297mm
    const data = editableData;

    // Helpers
    const addText = (text: string, x: number, y: number, fontSize = 10, font = 'helvetica', style = 'normal') => {
        doc.setFont(font, style);
        doc.setFontSize(fontSize);
        doc.text(text, x, y);
    };
    const addLine = (x1: number, y1: number, x2: number, y2: number) => {
        doc.setLineWidth(0.2);
        doc.line(x1, y1, x2, y2);
    };
    const addValue = (value: string, x: number, y: number) => {
         doc.setFont('helvetica', 'bold'); // Bold for filled values
         doc.setFontSize(10);
         // Slightly offset Y to sit on the line better
         doc.text(String(value || ''), x, y - 1);
    };

    // --- HEADER ---
    // Xtenda Logo Placeholder (Top Right)
    doc.setTextColor(255, 140, 0); // Orange
    addText("X", 180, 15, 24, 'helvetica', 'bold');
    addText("Xtenda", 175, 22, 12, 'helvetica', 'bold');
    doc.setTextColor(0, 0, 0); // Reset to black

    // Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text("SALARY ADVANCE APPLICATION FORM", 105, 25, { align: 'center' });

    // Date
    addText("DATE OF APPLICATION", 20, 35, 10, 'helvetica', 'bold');
    addLine(65, 35, 150, 35);
    addValue(new Date(data.dateOfApplication).toLocaleDateString(), 70, 35);

    // --- PERSONAL DETAILS ---
    addText("PERSONAL DETAILS", 20, 45, 11, 'helvetica', 'bold');

    // Row 1
    addText("FIRST NAME", 20, 55);
    addLine(45, 55, 105, 55);
    addValue(data.fullNames.split(' ')[0] || data.fullNames, 47, 55);

    addText("SURNAME", 115, 55);
    addLine(138, 55, 195, 55);
    addValue(data.fullNames.split(' ').slice(1).join(' '), 140, 55);

    // Row 2
    addText("NRC", 20, 65);
    addLine(45, 65, 105, 65);
    addValue(data.nrc, 47, 65);

    addText("EMPLOYEE NUMBER", 115, 65);
    addLine(155, 65, 195, 65);
    addValue(data.employeeNumber, 157, 65);

    // Row 3
    addText("EMPLOYER", 20, 75);
    addLine(45, 75, 105, 75);
    addValue(data.employer, 47, 75);

    addText("PHONE", 115, 75);
    addLine(138, 75, 195, 75);
    addValue(data.phone, 140, 75);

    // Row 4
    addText("EMAIL", 20, 85);
    addLine(45, 85, 195, 85);
    addValue(data.email, 47, 85);

    // Row 5
    addText("EMPLOYMENT ADDRESS", 20, 95);
    addLine(65, 95, 195, 95);
    addValue(data.employmentAddress, 67, 95);

    // Row 6
    addText("EMPLOYMENT TERMS (PERMANENT/CONTRACT)", 20, 105);
    addLine(105, 105, 195, 105);
    addValue(data.employmentTerms, 110, 105);

    // Row 7
    addText("GROSS SALARY", 20, 115);
    addLine(50, 115, 130, 115);
    addValue(data.grossSalary ? `K${data.grossSalary}` : '', 52, 115);

    // Row 8
    addText("NET SALARY", 20, 125);
    addLine(50, 125, 130, 125);
    addValue(data.netSalary ? `K${data.netSalary}` : '', 52, 125);

    // --- NEXT OF KIN DETAILS ---
    addText("NEXT OF KIN DETAILS", 20, 140, 11, 'helvetica', 'bold');

    // Row 1
    addText("FULL NAMES", 20, 150);
    addLine(45, 150, 115, 150);
    addValue(data.kinFullNames, 47, 150);

    addText("NRC", 120, 150);
    addLine(130, 150, 195, 150);
    addValue(data.kinNrc, 132, 150);

    // Row 2
    addText("RELATIONSHIP", 20, 160);
    addLine(50, 160, 115, 160);
    addValue(data.kinRelationship, 52, 160);

    addText("PHONE", 120, 160);
    addLine(135, 160, 195, 160);
    addValue(data.kinPhone, 137, 160);

    // Row 3
    addText("RESIDENTIAL ADDRESS", 20, 170);
    addLine(65, 170, 195, 170);
    addValue(data.kinResidentialAddress, 67, 170);

    // --- BANK DETAILS ---
    addText("SALARY BANK DETAILS", 20, 185, 11, 'helvetica', 'bold');
    // Simple table-like structure using lines
    const startY = 190;
    const rowH = 8;
    doc.rect(20, startY, 175, rowH * 4); // Outer border
    addLine(70, startY, 70, startY + rowH * 4); // Vertical separator
    addLine(20, startY + rowH, 195, startY + rowH); // Row 1 line
    addLine(20, startY + rowH * 2, 195, startY + rowH * 2); // Row 2 line
    addLine(20, startY + rowH * 3, 195, startY + rowH * 3); // Row 3 line

    // Labels
    addText("BANK NAME", 23, startY + 6, 10, 'helvetica', 'bold');
    addText("BRANCH NAME", 23, startY + rowH + 6, 10, 'helvetica', 'bold');
    addText("ACCOUNT NUMBER", 23, startY + rowH * 2 + 6, 10, 'helvetica', 'bold');
    addText("ACCOUNT NAMES", 23, startY + rowH * 3 + 6, 10, 'helvetica', 'bold');

    // Values
    addValue(data.bankName, 75, startY + 6);
    addValue(data.branchName, 75, startY + rowH + 6);
    addValue(data.accountNumber, 75, startY + rowH * 2 + 6);
    addValue(data.fullNames, 75, startY + rowH * 3 + 6); // Assuming account name is applicant name

    // --- ADVANCE DETAILS ---
    const advY = 230;
    addText("ADVANCE DETAILS", 20, advY - 5, 11, 'helvetica', 'bold');
    doc.rect(20, advY, 175, rowH * 6); // Outer border 6 rows
    addLine(110, advY, 110, advY + rowH * 6); // Vertical separator
    for(let i=1; i<6; i++) {
         addLine(20, advY + rowH * i, 195, advY + rowH * i);
    }

    // Labels
    addText("PURPOSE FOR THE ADVANCE", 23, advY + 6, 9, 'helvetica', 'bold');
    addText("SOURCE OF PROCEEDS FOR REPAYMENT", 23, advY + rowH + 6, 9, 'helvetica', 'bold');
    addText("NUMBER OF OTHER LOANS/OBLIGATIONS", 23, advY + rowH * 2 + 6, 9, 'helvetica', 'bold');
    addText("ADVANCE AMOUNT (ZMW)", 23, advY + rowH * 3 + 6, 9, 'helvetica', 'bold');
    addText("MONTHLY INSTALLMENT", 23, advY + rowH * 4 + 6, 9, 'helvetica', 'bold');
    addText("ADVANCE TENURE", 23, advY + rowH * 5 + 6, 9, 'helvetica', 'bold');

    // Values
    addValue(data.loanPurpose || '', 115, advY + 6);
    addValue("Salary", 115, advY + rowH + 6); // Default source
    addValue("None Declared", 115, advY + rowH * 2 + 6); // Default if not asked
    if (data.loanDetails) {
        addValue(new Intl.NumberFormat('en-US').format(data.loanDetails.amount), 115, advY + rowH * 3 + 6);
        addValue(new Intl.NumberFormat('en-US').format(data.loanDetails.monthlyPayment), 115, advY + rowH * 4 + 6);
        addValue(`${data.loanDetails.months} Months`, 115, advY + rowH * 5 + 6);
    }

    // --- DECLARATION ---
    const decY = 285; 
    addText("DECLARATION", 20, 285 - 5, 11, 'helvetica', 'bold');
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    const declarationText = `I, ${data.fullNames}, hereby apply for an Xtenda Salary Advance and authorize the recovery of the loan issued to be deducted through my Bank Account. I further confirm that the DDACC confirmation provided to Xtenda Finance Limited for purposes of recovery of the advance I am obtaining are being issued on a sufficiently funded account and that I accept any action which my bank and/or Xtenda Finance Limited will take against me should the DDACC instruction bounce on grounds of insufficient funds on my bank account and/or any other reason which may lead to Xtenda Finance Limited not recovering as agreed. I also authorize Xtenda Finance Limited to take necessary legal action against me should this advance I am applying for go into arrears for any reason arising from my failure to honour this advance agreement.`;
    
    const splitText = doc.splitTextToSize(declarationText, 175);
    doc.text(splitText, 20, 285);

    // Signature area
    const sigY = 285 + splitText.length * 3.5 + 10; 
    
    if (sigY > 280) {
         doc.addPage();
         doc.text(splitText, 20, 20); 
         const newSigY = 20 + splitText.length * 3.5 + 10;
         addText("Signature", 20, newSigY + 15);
         addLine(40, newSigY + 15, 100, newSigY + 15);
         if (data.signature) {
             try {
                doc.addImage(data.signature, 'PNG', 45, newSigY, 40, 20);
             } catch(e) { console.warn("Could not add signature image", e); }
         }

         addText("Date", 120, newSigY + 15);
         addLine(130, newSigY + 15, 180, newSigY + 15);
         addValue(new Date(data.dateOfApplication).toLocaleDateString(), 135, newSigY + 15);

    } else {
         addText("Signature", 20, sigY);
         addLine(40, sigY, 100, sigY);
         if (data.signature) {
             try {
                doc.addImage(data.signature, 'PNG', 45, sigY - 15, 40, 20);
             } catch(e) { console.warn("Could not add signature image", e); }
         }

         addText("Date", 120, sigY);
         addLine(130, sigY, 180, sigY);
         addValue(new Date(data.dateOfApplication).toLocaleDateString(), 135, sigY);
    }

    doc.save(`Xtenda_Application_${data.fullNames.replace(/\s/g, '_')}.pdf`);
  };

  const renderField = (label: string, fieldName: string, type = 'text') => {
    const value = editableData[fieldName];
    const error = errors[fieldName];
    let content;

    if (isEditing && type !== 'readonly') {
        if (type === 'radio') {
            content = (
                <div className="flex gap-4 mt-1">
                    <label className="flex items-center cursor-pointer"><input type="radio" name={fieldName} value="Permanent" onChange={handleInputChange} checked={value === 'Permanent'} className="mr-2 h-4 w-4 text-orange-600 focus:ring-orange-500"/>Permanent</label>
                    <label className="flex items-center cursor-pointer"><input type="radio" name={fieldName} value="Contract" onChange={handleInputChange} checked={value === 'Contract'} className="mr-2 h-4 w-4 text-orange-600 focus:ring-orange-500"/>Contract</label>
                </div>
            );
        } else if (type === 'checkbox') {
            content = (
                <input
                    type="checkbox"
                    name={fieldName}
                    checked={!!value}
                    onChange={(e) => setEditableData((prev: any) => ({...prev, [fieldName]: e.target.checked }))}
                    className="h-5 w-5 mt-1 text-green-600 border-gray-300 rounded focus:ring-green-500"
                />
            );
        } else {
            content = (
                <>
                    <input
                        type={type}
                        name={fieldName}
                        value={value || ''}
                        onChange={handleInputChange}
                        className={`w-full p-2 border rounded-lg focus:ring-2 focus:ring-orange-500 transition-all ${error ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                    />
                    {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
                </>
            );
        }
    } else {
        // Read-only "Blue Pen" Mode
        const displayValue = value ? (typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value) : '';
        content = displayValue ? (
            <div className="relative pt-1">
                <span className="font-pen text-blue-pen text-2xl leading-none relative z-10" style={{ top: '2px' }}>
                    {displayValue}
                </span>
                {/* Subtle dotted line underneath to look like a form field */}
                <div className="absolute bottom-0 left-0 right-0 border-b-2 border-dotted border-gray-300 opacity-50 -z-0" style={{ bottom: '4px' }}></div>
            </div>
        ) : (
            <span className="text-gray-300 italic border-b border-dotted border-gray-200 w-full block py-1">Empty</span>
        );
    }

    return (
        <div className="py-3 sm:grid sm:grid-cols-3 sm:gap-4 items-baseline border-b border-gray-50 last:border-0">
            <dt className="text-sm font-bold text-gray-600 uppercase tracking-wider">{label}</dt>
            <dd className="mt-1 sm:mt-0 sm:col-span-2">{content}</dd>
        </div>
    );
  };

  const handleDownloadCSV = () => {
    const headers = ['Field', 'Value'];
    const rows = Object.entries(editableData).map(([key, value]) => {
      let formattedValue;
      const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());
      if (typeof value === 'boolean') formattedValue = value ? 'Yes' : 'No';
      else if (typeof value === 'string' && value.startsWith('data:')) formattedValue = 'File Data (See Admin Panel)';
      else if (typeof value === 'object' && value !== null) formattedValue = JSON.stringify(value);
      else formattedValue = `"${String(value || '').replace(/"/g, '""')}"`;
      return [formattedKey, formattedValue];
    });
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const safeFileName = (editableData.fullNames || 'submission').replace(/[^a-z0-9]/gi, '_').toLowerCase();
    link.setAttribute("download", `application_${safeFileName}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusColor = (status: string) => {
      switch(status?.toLowerCase()) {
          case 'approved': return 'bg-green-100 text-green-800 border-green-200';
          case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
          case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
          case 'reviewing': return 'bg-blue-100 text-blue-800 border-blue-200';
          default: return 'bg-gray-100 text-gray-800 border-gray-200'; // New or unknown
      }
  };

  const renderDocumentLink = (dataUrl: string | null, filenamePrefix: string) => {
      if (!dataUrl) return <span className="text-gray-300 italic">Not provided</span>;
      const isImage = dataUrl.startsWith('data:image');
      const isPdf = dataUrl.startsWith('data:application/pdf');

      return (
          <div className="mt-1 flex flex-wrap items-center gap-4">
              {isImage && (
                  <a href={dataUrl} target="_blank" rel="noopener noreferrer" className="block border-2 border-gray-200 hover:border-orange-400 rounded-lg p-1 bg-white shadow-sm transition-all duration-200 hover:shadow-md max-w-[150px]">
                      <img src={dataUrl} alt={filenamePrefix} className="w-full h-auto rounded" />
                  </a>
              )}
               <a 
                href={dataUrl} 
                download={`${filenamePrefix}_${editableData.fullNames?.replace(/\s/g, '_') || 'applicant'}.${isPdf ? 'pdf' : 'png'}`}
                className="bg-blue-50 text-blue-600 font-semibold py-2 px-4 rounded-lg hover:bg-blue-100 transition flex items-center gap-2 text-sm border border-blue-100"
               >
                   <i className={`fa-solid ${isPdf ? 'fa-file-pdf' : 'fa-image'}`}></i> Download {isPdf ? 'PDF' : 'Image'}
               </a>
          </div>
      )
  }

  return (
    <div className="min-h-screen bg-gray-100 font-sans p-4 sm:p-6 md:p-8">
      <div className="max-w-5xl mx-auto">
        <header className="bg-white shadow-sm p-4 md:p-6 rounded-t-xl border-b flex flex-col md:flex-row justify-between items-start md:items-center gap-4 sticky top-0 z-10">
            <div className="flex items-center gap-4 flex-1">
                {onBack && (
                    <button onClick={onBack} className="bg-gray-100 text-gray-600 p-2.5 rounded-full hover:bg-gray-200 transition shrink-0" title="Back to Dashboard">
                        <i className="fa-solid fa-arrow-left"></i>
                    </button>
                )}
                <div>
                  <div className="flex items-center gap-3 mb-1">
                      <h1 className="text-xl md:text-2xl font-extrabold text-gray-800">
                        Application Review
                      </h1>
                      {isEditing ? (
                          <select 
                              name="status" 
                              value={editableData.status || 'New'} 
                              onChange={handleInputChange}
                              className="text-sm font-bold p-1.5 rounded-lg border-2 border-orange-200 focus:border-orange-500 focus:ring-0 bg-orange-50 text-orange-800 cursor-pointer"
                          >
                              <option value="New">New</option>
                              <option value="Pending">Pending</option>
                              <option value="Reviewing">Reviewing</option>
                              <option value="Approved">Approved</option>
                              <option value="Rejected">Rejected</option>
                          </select>
                      ) : (
                          <span className={`px-3 py-1 text-xs font-bold uppercase rounded-full border ${getStatusColor(editableData.status || 'New')}`}>
                              {editableData.status || 'New'}
                          </span>
                      )}
                  </div>
                  <p className="text-sm text-gray-500">Applicant ID: <span className="font-mono text-xs">{editableData.id?.substring(0,8)}...</span></p>
                </div>
            </div>
             <div className="flex flex-wrap items-center gap-3 self-end md:self-auto shrink-0">
                 <button onClick={handleEmailApplicant} className="bg-white border-2 border-blue-500 text-blue-600 font-bold py-2 px-4 rounded-lg hover:bg-blue-50 transition duration-300 flex items-center gap-2 text-sm">
                    <i className="fa-solid fa-paper-plane"></i> Email
                </button>
                 <button onClick={generatePDF} className="bg-white border-2 border-orange-500 text-orange-600 font-bold py-2 px-4 rounded-lg hover:bg-orange-50 transition duration-300 flex items-center gap-2 text-sm">
                    <i className="fa-solid fa-file-pdf"></i> PDF
                </button>

                {isEditing ? (
                    <>
                         <label className={`flex items-center gap-2 text-sm font-medium cursor-pointer px-3 py-2 rounded-lg border transition ${notifySMS ? 'bg-blue-100 text-blue-800 border-blue-300' : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'}`}>
                            <input
                                type="checkbox"
                                checked={notifySMS}
                                onChange={(e) => setNotifySMS(e.target.checked)}
                                className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                            />
                            <i className="fa-solid fa-comment-sms"></i>
                            Notify SMS
                        </label>
                        <button onClick={handleSave} disabled={saveMessage?.type === 'pending'} className="bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition duration-300 flex items-center gap-2 text-sm shadow-sm disabled:bg-gray-400 min-w-[140px] justify-center">
                            {saveMessage?.type === 'pending' ? (
                                <><i className="fa-solid fa-circle-notch fa-spin"></i> Saving...</>
                            ) : (
                                <><i className="fa-solid fa-floppy-disk"></i> Save</>
                            )}
                        </button>
                        <button onClick={handleCancel} disabled={saveMessage?.type === 'pending'} className="bg-gray-200 text-gray-700 font-bold py-2 px-4 rounded-lg hover:bg-gray-300 transition duration-300 flex items-center gap-2 text-sm disabled:opacity-50">
                            Cancel
                        </button>
                    </>
                ) : (
                    <button onClick={() => setIsEditing(true)} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300 flex items-center gap-2 text-sm shadow-sm">
                        <i className="fa-solid fa-pen-to-square"></i> Edit
                    </button>
                )}
                 <button onClick={handleDownloadCSV} className="text-gray-500 hover:text-gray-700 font-bold py-2 px-3 rounded-lg transition duration-300 flex items-center gap-2 text-sm" title="Download CSV">
                  <i className="fa-solid fa-file-csv text-xl"></i>
                </button>
            </div>
        </header>
        
        {saveMessage && (
             <div className={`p-3 text-center text-sm font-bold text-white ${saveMessage.type === 'success' ? 'bg-green-500' : saveMessage.type === 'pending' ? 'bg-blue-500' : 'bg-red-500'} animate-fade-in`}>
                {saveMessage.text}
            </div>
        )}

        <main className="bg-white rounded-b-xl shadow-md overflow-hidden">
            {/* Digital 'Paper' background effect */}
            <div className="p-8 md:p-12 space-y-10 bg-white relative" style={{ backgroundImage: 'radial-gradient(#f0f0f0 1px, transparent 1px)', backgroundSize: '20px 20px' }}>
                
                <section className="bg-white/90 p-6 rounded-2xl shadow-sm border border-gray-100 backdrop-blur-sm">
                     <h2 className="text-xl font-bold text-gray-800 flex items-center gap-3 mb-6">
                        <span className="bg-orange-100 text-orange-600 w-10 h-10 flex items-center justify-center rounded-full"><i className="fa-solid fa-folder-open"></i></span>
                        Documents
                    </h2>
                    <dl className="divide-y divide-gray-100">
                        <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 items-start">
                            <dt className="text-sm font-bold text-gray-600 pt-2 uppercase tracking-wider">Selfie</dt>
                            <dd className="mt-2 sm:mt-0 sm:col-span-2">{renderDocumentLink(editableData.selfie, 'Selfie')}</dd>
                        </div>
                        <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 items-start">
                            <dt className="text-sm font-bold text-gray-600 pt-2 uppercase tracking-wider">Latest Payslip</dt>
                            <dd className="mt-2 sm:mt-0 sm:col-span-2">{renderDocumentLink(editableData.latestPayslip, 'Payslip')}</dd>
                        </div>
                        <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 items-start">
                            <dt className="text-sm font-bold text-gray-600 pt-2 uppercase tracking-wider">NRC Front</dt>
                            <dd className="mt-2 sm:mt-0 sm:col-span-2">{renderDocumentLink(editableData.nrcFront, 'NRC_Front')}</dd>
                        </div>
                         <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 items-start">
                            <dt className="text-sm font-bold text-gray-600 pt-2 uppercase tracking-wider">NRC Back</dt>
                            <dd className="mt-2 sm:mt-0 sm:col-span-2">{renderDocumentLink(editableData.nrcBack, 'NRC_Back')}</dd>
                        </div>
                    </dl>
                </section>

                <section className="bg-white/90 p-6 rounded-2xl shadow-sm border border-gray-100 backdrop-blur-sm">
                    <h2 className="text-xl font-bold text-gray-800 flex items-center gap-3 mb-6">
                        <span className="bg-blue-100 text-blue-600 w-10 h-10 flex items-center justify-center rounded-full"><i className="fa-solid fa-user"></i></span>
                        Personal Details
                    </h2>
                    <div className="space-y-1">
                        {renderField("Date of Application", "dateOfApplication", "date")}
                        {renderField("Full Names", "fullNames")}
                        {renderField("NRC Number", "nrc")}
                        {renderField("Phone Number", "phone", "tel")}
                        {renderField("Email Address", "email", "email")}
                        {renderField("Residential Address", "employmentAddress")}
                    </div>
                </section>

                <section className="bg-white/90 p-6 rounded-2xl shadow-sm border border-gray-100 backdrop-blur-sm">
                   <h2 className="text-xl font-bold text-gray-800 flex items-center gap-3 mb-6">
                        <span className="bg-green-100 text-green-600 w-10 h-10 flex items-center justify-center rounded-full"><i className="fa-solid fa-briefcase"></i></span>
                        Employment & Loan
                    </h2>
                    <div className="space-y-1">
                        {renderField("Employer", "employer")}
                        {renderField("Employee No.", "employeeNumber")}
                        {renderField("Terms", "employmentTerms", "radio")}
                        <div className="grid grid-cols-2 gap-4">
                             {renderField("Gross Pay (ZMW)", "grossSalary")}
                             {renderField("Net Pay (ZMW)", "netSalary")}
                        </div>
                        {renderField("Loan Purpose", "loanPurpose")}
                    </div>
                    {editableData.loanDetails && (
                         <div className="mt-6 p-4 bg-orange-50 rounded-xl border border-orange-100">
                            <h3 className="font-bold text-orange-800 mb-3 text-sm uppercase tracking-wider border-b border-orange-200 pb-2">Requested Advance</h3>
                            <div className="grid grid-cols-3 gap-4 text-center">
                                <div>
                                    <span className="block text-xs text-orange-600 font-medium uppercase mb-1">Amount</span>
                                    <span className="font-pen text-blue-pen text-3xl">K{editableData.loanDetails.amount}</span>
                                </div>
                                <div>
                                    <span className="block text-xs text-orange-600 font-medium uppercase mb-1">Period</span>
                                    <span className="font-pen text-blue-pen text-3xl">{editableData.loanDetails.months} <span className="text-xl">months</span></span>
                                </div>
                                <div>
                                    <span className="block text-xs text-orange-600 font-medium uppercase mb-1">Monthly</span>
                                    <span className="font-pen text-blue-pen text-3xl">K{editableData.loanDetails.monthlyPayment}</span>
                                </div>
                            </div>
                        </div>
                    )}
                </section>

                 <div className="grid md:grid-cols-2 gap-8">
                    <section className="bg-white/90 p-6 rounded-2xl shadow-sm border border-gray-100 backdrop-blur-sm">
                         <h2 className="text-lg font-bold text-gray-800 flex items-center gap-3 mb-6">
                            <span className="bg-purple-100 text-purple-600 w-8 h-8 flex items-center justify-center rounded-full text-sm"><i className="fa-solid fa-users"></i></span>
                            Next of Kin
                        </h2>
                        <div className="space-y-1">
                            {renderField("Full Names", "kinFullNames")}
                            {renderField("Relationship", "kinRelationship")}
                            {renderField("Phone", "kinPhone", "tel")}
                            {renderField("Address", "kinResidentialAddress")}
                             {renderField("NRC (Optional)", "kinNrc")}
                        </div>
                    </section>

                    <section className="bg-white/90 p-6 rounded-2xl shadow-sm border border-gray-100 backdrop-blur-sm">
                        <h2 className="text-lg font-bold text-gray-800 flex items-center gap-3 mb-6">
                            <span className="bg-gray-100 text-gray-600 w-8 h-8 flex items-center justify-center rounded-full text-sm"><i className="fa-solid fa-building-columns"></i></span>
                            Bank Details
                        </h2>
                        <div className="space-y-1">
                            {renderField("Bank Name", "bankName")}
                            {renderField("Branch", "branchName")}
                            {renderField("Account No.", "accountNumber")}
                        </div>
                    </section>
                </div>

                <section className="bg-white/90 p-6 rounded-2xl shadow-sm border border-gray-100 backdrop-blur-sm flex flex-col md:flex-row justify-between items-end gap-6">
                    <div className="flex-1">
                        <h2 className="text-lg font-bold text-gray-800 mb-4">Declaration</h2>
                        <div className="flex items-center gap-2 mb-4">
                            {isEditing ? (
                                <input type="checkbox" checked={editableData.declarationAgreed} onChange={(e) => setEditableData({...editableData, declarationAgreed: e.target.checked})} className="h-5 w-5 text-green-600"/>
                            ) : (
                                <i className={`fa-solid ${editableData.declarationAgreed ? 'fa-square-check text-green-600' : 'fa-square text-gray-300'} text-2xl`}></i>
                            )}
                            <span className="text-gray-700 font-medium">Agreed to Terms & Conditions</span>
                        </div>
                    </div>
                    <div>
                         <p className="text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">Authorized Signature</p>
                         {editableData.signature ? (
                             <div className="border-2 border-blue-100 rounded-xl p-3 bg-blue-50/50 min-w-[200px]">
                                <img src={editableData.signature} alt="Client Signature" className="max-h-16 mix-blend-multiply opacity-90" />
                             </div>
                         ) : (
                             <div className="h-20 min-w-[200px] border-2 border-dashed border-red-200 bg-red-50 rounded-xl flex items-center justify-center text-red-400 font-bold uppercase text-sm">
                                 No Signature
                             </div>
                         )}
                    </div>
                </section>

            </div>
        </main>
      </div>
      <AdminChatbot applicationData={editableData} />
      <style>{`
        .font-pen {
            font-family: 'Caveat', cursive;
        }
        .text-blue-pen {
            color: #2563eb; /* Stronger blue for better visibility */
        }
        .animate-fade-in { animation: fadeIn 0.3s ease-out; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      `}</style>
    </div>
  );
};

export default AdminView;
