import React from 'react';

interface FileUploadProps {
    label: string;
    fileType: string;
    onFileSelect: (dataUrl: string | null, fileName: string | null) => void;
}

const MAX_FILE_SIZE_MB = 5;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

const FileUpload = ({ label, fileType, onFileSelect }: FileUploadProps) => {
  const [fileName, setFileName] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);
  const [isDragging, setIsDragging] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const [isReading, setIsReading] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
      setIsReading(true);
      setProgress(0);
      setError(null);

      const reader = new FileReader();

      reader.onprogress = (event) => {
          if (event.lengthComputable) {
              const percentLoaded = Math.round((event.loaded / event.total) * 100);
              setProgress(percentLoaded);
          }
      };

      reader.onload = (e) => {
          setProgress(100);
          // Small delay to let user see 100%
          setTimeout(() => {
              setFileName(file.name);
              onFileSelect(e.target?.result as string, file.name);
              setIsReading(false);
          }, 500);
      };

      reader.onerror = () => {
          setError("Failed to read file. Please try again.");
          setIsReading(false);
          onFileSelect(null, null);
      };

      reader.readAsDataURL(file);
  };

  const validateAndProcessFile = (file: File) => {
      setError(null);

      // 1. Validate Size
      if (file.size > MAX_FILE_SIZE_BYTES) {
          setError(`File is too large. Maximum size is ${MAX_FILE_SIZE_MB}MB.`);
          setFileName('');
          onFileSelect(null, null);
          return;
      }

      // 2. Validate Type
      const acceptedTypes = fileType.split(',').map(t => t.trim());
      const isTypeValid = acceptedTypes.some(type => {
          if (type.endsWith('/*')) {
              const baseType = type.split('/')[0];
              return file.type.startsWith(baseType + '/');
          }
          return file.type === type;
      });

      if (!isTypeValid && fileType !== '*') {
           setError(`Invalid file type.`);
           setFileName('');
           onFileSelect(null, null);
           return;
      }

      // Valid, now read it with progress
      processFile(file);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        validateAndProcessFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      if (!isReading) setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragging(false);
      if (isReading) return;
      
      const file = e.dataTransfer.files?.[0];
      if (file) {
          validateAndProcessFile(file);
      }
  };

  const handleButtonClick = () => {
    if (!isReading) fileInputRef.current?.click();
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div 
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md transition-all duration-200 relative overflow-hidden ${isDragging ? 'border-orange-500 bg-orange-50' : (error ? 'border-red-300 bg-red-50' : 'border-gray-300')}`}
      >
        {isReading ? (
            <div className="w-full flex flex-col items-center justify-center py-4 space-y-3">
                 <div className="w-full max-w-xs bg-gray-200 rounded-full h-2.5 overflow-hidden">
                    <div className="bg-orange-500 h-2.5 rounded-full transition-all duration-300 ease-out" style={{ width: `${progress}%` }}></div>
                 </div>
                 <p className="text-sm text-orange-600 font-bold animate-pulse">Uploading... {progress}%</p>
            </div>
        ) : (
            <div className="space-y-1 text-center">
            {error ? (
                <i className="fa-solid fa-triangle-exclamation mx-auto h-12 w-12 text-red-500 text-3xl pt-2"></i>
            ) : (
                <i className={`fa-solid ${fileName ? 'fa-file-circle-check text-green-500' : 'fa-cloud-arrow-up text-gray-400'} mx-auto h-12 w-12 text-3xl pt-2 transition-colors duration-300`}></i>
            )}
            
            <div className="flex text-sm text-gray-600 flex-col">
                <button
                type="button"
                onClick={handleButtonClick}
                className="relative cursor-pointer bg-transparent rounded-md font-medium text-orange-600 hover:text-orange-500 focus-within:outline-none"
                >
                <span>{fileName ? 'Change file' : 'Upload a file'}</span>
                <input ref={fileInputRef} type="file" accept={fileType} className="sr-only" onChange={handleFileChange} />
                </button>
                {!fileName && <p className="pl-1 mt-1">or drag and drop</p>}
            </div>
            
            {error ? (
                <p className="text-sm text-red-600 font-semibold">{error}</p>
            ) : fileName ? (
                <p className="text-sm text-green-600 font-semibold break-all">{fileName}</p>
            ) : (
                <p className="text-xs text-gray-500">
                    {fileType.includes('pdf') ? 'PDF or Images' : 'Supported files'} up to {MAX_FILE_SIZE_MB}MB
                </p>
            )}
            </div>
        )}
      </div>
    </div>
  );
};

export default FileUpload;