
import React from 'react';
import { ScheduleEntry } from '../types';
import { logVisitorEvent } from '../utils';

interface SalaryCalculatorProps {
    schedule: ScheduleEntry[];
    isAdmin: boolean;
    onScheduleChange: (newSchedule: ScheduleEntry[]) => void;
    onLoanChange?: (details: { amount: number, months: number, monthlyPayment: number }) => void;
    onNavigate: (page: 'home' | 'apply' | 'contact') => void;
}

const SalaryCalculator = ({ schedule, isAdmin, onScheduleChange, onLoanChange, onNavigate }: SalaryCalculatorProps) => {
  // Default to K10,000 for 6 months as requested
  const [selectedAmount, setSelectedAmount] = React.useState<number>(10000);
  const [selectedMonths, setSelectedMonths] = React.useState(6);
  const repaymentPeriods = [1, 2, 3, 4, 5, 6];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ZMW', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);
  };

  // Helper to find min and max from schedule for UI constraints
  const minAmount = React.useMemo(() => Math.min(...schedule.map(s => s.disbursedAmount)), [schedule]);
  const maxAmount = React.useMemo(() => Math.max(...schedule.map(s => s.disbursedAmount)), [schedule]);

  const sortedAmounts = React.useMemo(() => {
      return [...schedule].map(s => s.disbursedAmount).sort((a, b) => a - b);
  }, [schedule]);

  const calculateDynamicInstallment = React.useCallback((amount: number, months: number): number => {
    if (amount <= 0) return 0;

    // 1. Exact match lookup
    const exactMatch = schedule.find(s => s.disbursedAmount === amount);
    if (exactMatch) {
        return exactMatch.installments[months];
    }

    // 2. Sort schedule to ensure correct interpolation
    const sortedSchedule = [...schedule].sort((a, b) => a.disbursedAmount - b.disbursedAmount);

    // 3. Handle extrapolation below minimum
    if (amount < sortedSchedule[0].disbursedAmount) {
        const base = sortedSchedule[0];
        const ratio = amount / base.disbursedAmount;
        return base.installments[months] * ratio;
    }

    // 4. Handle extrapolation above maximum
    if (amount > sortedSchedule[sortedSchedule.length - 1].disbursedAmount) {
        const base = sortedSchedule[sortedSchedule.length - 1];
        const ratio = amount / base.disbursedAmount;
        return base.installments[months] * ratio;
    }

    // 5. Linear interpolation between two points
    for (let i = 0; i < sortedSchedule.length - 1; i++) {
        const lower = sortedSchedule[i];
        const upper = sortedSchedule[i+1];
        if (amount > lower.disbursedAmount && amount < upper.disbursedAmount) {
            const ratio = (amount - lower.disbursedAmount) / (upper.disbursedAmount - lower.disbursedAmount);
            const lowerInstallment = lower.installments[months];
            const upperInstallment = upper.installments[months];
            return lowerInstallment + ratio * (upperInstallment - lowerInstallment);
        }
    }

    return 0;
  }, [schedule]);

  const calculation = React.useMemo(() => {
    const monthlyPayment = calculateDynamicInstallment(selectedAmount, selectedMonths);
    const totalRepayment = selectedMonths === 1 ? monthlyPayment : monthlyPayment * selectedMonths;
    const totalCost = totalRepayment - selectedAmount;
    
    return { monthlyPayment, totalRepayment, totalCost };
  }, [selectedAmount, selectedMonths, calculateDynamicInstallment]);

  // Notify parent of changes
  React.useEffect(() => {
      if (onLoanChange) {
          onLoanChange({
              amount: selectedAmount,
              months: selectedMonths,
              monthlyPayment: calculation.monthlyPayment
          });
      }
  }, [selectedAmount, selectedMonths, calculation.monthlyPayment, onLoanChange]);

  const handleScheduleEdit = (index: number, field: string, value: string) => {
    const newSchedule = JSON.parse(JSON.stringify(schedule));
    const numValue = parseInt(value, 10);

    if (!isNaN(numValue)) {
      if (field.startsWith('installments.')) {
        const monthKey = Number(field.split('.')[1]);
        newSchedule[index].installments[monthKey] = numValue;
      } else if (field === 'disbursedAmount') {
        newSchedule[index].disbursedAmount = numValue;
      }
      onScheduleChange(newSchedule);
    }
  };

  const handleApplyClick = () => {
      logVisitorEvent('INTEREST', `Selected loan: K${selectedAmount} for ${selectedMonths} months`);
      onNavigate('apply');
  }

  return (
    <section id="calculator" className="my-16 p-3 md:p-8 bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      {/* FORCE SIDE-BY-SIDE ON ALL DEVICES as requested */}
      <div className="grid grid-cols-2 gap-2 md:gap-8 items-start">
        
        {/* Loan Amount Section */}
        <div className="bg-green-50 p-2 md:p-6 rounded-xl border-l-2 md:border-l-4 border-green-500 space-y-4 md:space-y-6">
          <div>
              <h3 className="text-sm md:text-lg font-bold text-gray-700 mb-2 md:mb-4">Select Loan Amount (ZMW)</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 md:gap-2 max-h-[250px] overflow-y-auto p-1 -mx-1 custom-scrollbar">
                  {sortedAmounts.map(amt => (
                      <button
                          key={amt}
                          type="button"
                          onClick={() => setSelectedAmount(amt)}
                          className={`py-2 px-1 rounded-md md:rounded-lg font-bold text-xs md:text-sm transition-all duration-200 ${
                              selectedAmount === amt
                                  ? 'bg-green-600 text-white shadow-md transform scale-105 sticky-hover'
                                  : 'bg-white border border-green-200 text-gray-700 hover:bg-green-100 hover:border-green-300'
                          }`}
                      >
                          {new Intl.NumberFormat('en-US').format(amt)}
                      </button>
                  ))}
              </div>
          </div>

          <div>
              <h3 className="text-sm md:text-lg font-bold text-gray-700 mb-2 md:mb-4">Months</h3>
              {/* Forced 6 cols, tiny on mobile */}
              <div className="grid grid-cols-6 gap-1">
                {repaymentPeriods.map(period => (
                  <button
                    key={period}
                    type="button"
                    onClick={() => setSelectedMonths(period)}
                    className={`py-2 md:py-3 rounded-md md:rounded-lg font-bold text-xs md:text-base transition-all duration-200 ${selectedMonths === period ? 'bg-green-600 text-white shadow-md transform scale-105' : 'bg-white border border-green-200 text-gray-700 hover:bg-green-100 hover:border-green-300'}`}
                  >
                    {period}
                  </button>
                ))}
              </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="bg-orange-50 p-3 md:p-6 rounded-xl border-l-2 md:border-l-4 border-orange-500 sticky top-24">
          <h3 className="text-sm md:text-lg font-bold text-gray-700 mb-4 md:mb-6">Repayment</h3>
          <div className="space-y-4 md:space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center p-2 md:p-4 bg-white rounded-lg shadow-sm border border-orange-100">
              <span className="text-gray-600 font-medium text-xs md:text-base">{selectedMonths === 1 ? 'Total:' : 'Monthly:'}</span>
              <span className="font-extrabold text-lg md:text-3xl text-green-600 break-all">{formatCurrency(calculation.monthlyPayment)}</span>
            </div>
            
            <div className="space-y-2 md:space-y-3 px-1 md:px-2">
                 <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center text-xs md:text-sm">
                  <span className="text-gray-600">Loan Amount:</span>
                  <span className="font-semibold text-gray-800">{formatCurrency(selectedAmount)}</span>
                </div>
                 <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center text-xs md:text-sm">
                  <span className="text-gray-600">Tenure:</span>
                  <span className="font-semibold text-gray-800">{selectedMonths} {selectedMonths === 1 ? 'Month' : 'Months'}</span>
                </div>
            </div>
          </div>

          <div className="mt-4 md:mt-8">
            <button 
                onClick={handleApplyClick}
                className="w-full bg-green-600 text-white font-bold py-2 md:py-4 px-2 md:px-6 rounded-lg md:rounded-xl hover:bg-green-700 transition duration-300 text-sm md:text-lg shadow-md flex items-center justify-center gap-1 animate-pulse-slow"
            >
                <span>Apply for {formatCurrency(selectedAmount)}</span>
                <i className="fa-solid fa-arrow-right ml-1"></i>
            </button>
          </div>
        </div>
      </div>
      
      {isAdmin && (
        <div className="mt-8 pt-6 border-t border-dashed">
          <h3 className="text-xl font-bold text-red-700 mb-4">Admin Panel: Edit Base Schedule</h3>
          <p className="text-sm text-gray-500 mb-4">Custom amounts are interpolated from these base values.</p>
          <div className="overflow-x-auto max-h-96">
            <table className="min-w-full divide-y divide-gray-200 relative">
              <thead className="bg-gray-50 sticky top-0 shadow-sm">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider bg-gray-50">Disbursed</th>
                  {repaymentPeriods.map(p => <th key={p} className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider bg-gray-50">{p} Mo</th>)}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {schedule.map((entry, index) => (
                  <tr key={index}>
                    <td className="px-2 py-1 whitespace-nowrap">
                      <input type="number" value={entry.disbursedAmount} onChange={e => handleScheduleEdit(index, 'disbursedAmount', e.target.value)} className="w-24 p-1 border rounded font-bold" />
                    </td>
                    {repaymentPeriods.map(p => (
                      <td key={p} className="px-2 py-1 whitespace-nowrap">
                        <input type="number" value={entry.installments[p]} onChange={e => handleScheduleEdit(index, `installments.${p}`, e.target.value)} className="w-20 p-1 border rounded text-sm" />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <style>{`
        @keyframes pulse-slow {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.9; }
        }
        .animate-pulse-slow {
            animation: pulse-slow 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        /* Custom thin scrollbar for the amounts grid */
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #16a34a;
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #15803d;
        }
      `}</style>
    </section>
  );
};

export default SalaryCalculator;
