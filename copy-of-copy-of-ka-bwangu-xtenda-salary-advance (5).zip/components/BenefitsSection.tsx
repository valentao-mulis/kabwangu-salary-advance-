
import React from 'react';

const BenefitsSection = () => {
  const benefits = [
    { 
        icon: 'fa-solid fa-rocket', 
        title: 'Lightning Fast', 
        description: 'Approvals in minutes, not days. We value your time.' 
    },
    { 
        icon: 'fa-solid fa-bolt', 
        title: 'Instant Payment', 
        description: 'Funds sent directly to your account instantly upon approval.' 
    },
    { 
        icon: 'fa-solid fa-sliders', 
        title: 'Flexible Terms', 
        description: 'Choose a repayment plan from 1 to 6 months that fits your budget perfectly.' 
    },
    { 
        icon: 'fa-solid fa-percent', 
        title: 'Competitive Rates', 
        description: 'Enjoy fair, transparent pricing with no any fees deducted' 
    },
  ];

  return (
    <section className="my-16 py-8 md:py-12 bg-white rounded-3xl shadow-xl overflow-hidden relative mx-4 md:mx-0 animate-fade-in">
       {/* Decorative background blobs */}
       <div className="absolute top-0 right-0 -mt-24 -mr-24 w-80 h-80 bg-orange-100 rounded-full opacity-40 blur-3xl pointer-events-none"></div>
       <div className="absolute bottom-0 left-0 -mb-24 -ml-24 w-80 h-80 bg-green-100 rounded-full opacity-40 blur-3xl pointer-events-none"></div>

      <div className="container mx-auto px-6 md:px-10 relative z-10">
        <div className="md:flex items-center gap-12 lg:gap-20">
          {/* Text Content */}
          <div className="md:w-1/2 mb-10 md:mb-0">
             <span className="inline-block py-1 px-3 rounded-full bg-green-100 text-green-600 text-sm font-bold mb-4">
                <i className="fa-solid fa-star mr-2"></i>Why Choose Us
             </span>
             <h2 className="text-3xl md:text-5xl font-extrabold text-gray-800 mb-6 leading-tight">
                <span className="text-orange-500">Ka Bwangu! The Smarter Way to Advance your salary</span>
             </h2>
             <p className="text-lg text-gray-600 mb-10 leading-relaxed">
                When emergencies strike, you need a partner who understands. Xtenda is designed to be the fastest, fairest, and most convenient way to access your salary early.
             </p>
             <div className="grid sm:grid-cols-2 gap-x-8 gap-y-10">
                {benefits.map((benefit, index) => (
                    <div key={index} className="flex flex-col items-start group">
                        <div className="bg-green-50 text-green-600 group-hover:bg-green-600 group-hover:text-white transition-colors duration-300 w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mb-4 shadow-sm">
                            <i className={benefit.icon}></i>
                        </div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">{benefit.title}</h3>
                        <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
                    </div>
                ))}
             </div>
          </div>

          {/* Illustrative Video */}
          <div className="md:w-1/2 relative">
             <div className="relative rounded-2xl overflow-hidden shadow-2xl transform md:rotate-3 group hover:rotate-0 transition duration-500 ease-out-back h-[500px] bg-gray-900">
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent z-10 pointer-events-none"></div>
                 
                 <video 
                    key="benefit-video-v2"
                    autoPlay 
                    loop 
                    muted 
                    playsInline
                    className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition duration-700"
                    poster="https://images.pexels.com/photos/3865557/pexels-photo-3865557.jpeg?auto=compress&cs=tinysrgb&w=800"
                 >
                     {/* Alternative stock video of happy person with phone */}
                     <source src="https://videos.pexels.com/video-files/6995204/6995204-hd_1920_1080_30fps.mp4" type="video/mp4" />
                     Your browser does not support the video tag.
                 </video>

                 {/* Floating badge */}
                 <div className="absolute bottom-6 left-6 right-6 z-20">
                     <div className="bg-white/95 backdrop-blur-md p-4 rounded-xl shadow-lg flex items-center gap-4 transform translate-y-2 group-hover:translate-y-0 transition duration-500">
                        <div className="bg-green-500 text-white rounded-full w-12 h-12 shrink-0 flex items-center justify-center text-xl shadow-md">
                            <i className="fa-solid fa-bell"></i>
                        </div>
                        <div>
                            <p className="font-extrabold text-gray-800 text-lg">Payment Received</p>
                            <p className="text-sm text-gray-600">Mobile Money • Just Now</p>
                        </div>
                     </div>
                 </div>
             </div>
             {/* Decorative element behind video */}
             <div className="absolute -inset-4 border-2 border-dashed border-green-300 rounded-3xl -z-10 md:rotate-3 transform scale-[1.02]"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
