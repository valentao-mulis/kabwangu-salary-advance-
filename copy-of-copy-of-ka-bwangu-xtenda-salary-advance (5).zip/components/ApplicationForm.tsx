
import React from 'react';
import { ApplicationFormData } from '../types';
import SignaturePad from './SignaturePad';
import FileUpload from './FileUpload';
import CameraCapture from './CameraCapture';
import { logVisitorEvent } from '../utils';

interface ApplicationFormProps {
    loanSummary?: {
        amount: number;
        months: number;
        monthlyPayment: number;
    };
}

const FormInput = ({
  label,
  name,
  formData,
  handleInputChange,
  placeholder = '',
  required = false,
  type = 'text',
  error,
}: {
  label: string;
  name: string;
  formData: any;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  placeholder?: string;
  required?: boolean;
  type?: string;
  error?: string;
}) => (
  <div>
    <label htmlFor={name} className="text-sm font-medium text-gray-600 mb-1 block">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
    </label>
    <input
      id={name}
      type={type}
      name={name}
      placeholder={placeholder || label}
      required={required}
      value={formData[name] || ''}
      onChange={handleInputChange}
      className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-white ${error ? 'border-red-500' : 'border-gray-300'}`}
    />
    {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
  </div>
);

const TermsModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl">
                <div className="p-5 border-b flex justify-between items-center sticky top-0 bg-white rounded-t-2xl z-10">
                    <h3 className="text-xl md:text-2xl font-bold text-gray-800">Terms and Conditions</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition p-2">
                        <i className="fa-solid fa-times text-xl"></i>
                    </button>
                </div>
                <div className="p-6 overflow-y-auto text-gray-700 space-y-6 leading-relaxed text-sm md:text-base">
                    <p className="font-bold text-gray-900 bg-orange-50 p-3 rounded-lg border-l-4 border-orange-500">
                        By submitting this application, you enter into a legally binding agreement with Xtenda Finance Limited. Please read these terms carefully.
                    </p>
                    
                    <section>
                        <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2 text-base">
                            <span className="bg-orange-100 text-orange-600 w-6 h-6 inline-flex items-center justify-center rounded-full text-xs flex-shrink-0">1</span>
                            Loan Recovery Method
                        </h4>
                        <p>
                            I hereby primarily authorize my employer to deduct the loan repayment installments directly from my salary at source (Payroll Deduction). I further authorize Xtenda Finance Limited to use Direct Debit and Clearing Committee (DDACC) instructions on my provided bank account only as a secondary recovery method should the primary payroll deduction fail for any reason.
                        </p>
                    </section>

                    <section>
                        <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2 text-base">
                            <span className="bg-orange-100 text-orange-600 w-6 h-6 inline-flex items-center justify-center rounded-full text-xs flex-shrink-0">2</span>
                            Default & Penalties
                        </h4>
                        <div className="space-y-2">
                            <p>In the event of a missed payment due to insufficient funds or any other reason:</p>
                            <ul className="list-disc pl-6 space-y-1 text-gray-600">
                                <li>A default penalty fee will be immediately charged to my account.</li>
                                <li>Interest will continue to accrue on the outstanding overdue balance.</li>
                                <li>Xtenda Finance Limited reserves the right to report the default to Credit Reference Bureaus (CRB), which may negatively affect my future borrowing ability.</li>
                            </ul>
                        </div>
                    </section>

                    <section>
                        <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2 text-base">
                            <span className="bg-orange-100 text-orange-600 w-6 h-6 inline-flex items-center justify-center rounded-full text-xs flex-shrink-0">3</span>
                            Legal Recourse & Collection Costs
                        </h4>
                        <p>
                            Should this account go into arrears, I explicitly authorize Xtenda Finance Limited to take necessary legal action to recover the full outstanding debt. I agree to be fully liable for all associated costs incurred during this process, including but not limited to legal practitioner fees, collection agency fees, and court costs.
                        </p>
                    </section>

                    <section>
                        <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2 text-base">
                            <span className="bg-orange-100 text-orange-600 w-6 h-6 inline-flex items-center justify-center rounded-full text-xs flex-shrink-0">4</span>
                            Employer Disclosure & Terminal Benefits
                        </h4>
                        <p>
                            I irrevocably authorize my current employer to disclose relevant financial or employment status details to Xtenda Finance Limited for the purpose of assessing and monitoring this loan. In the event of termination of employment while owing, I authorize my employer to deduct the outstanding loan balance from my terminal benefits or final salary payments upon request by Xtenda.
                        </p>
                    </section>

                    <section>
                        <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2 text-base">
                            <span className="bg-orange-100 text-orange-600 w-6 h-6 inline-flex items-center justify-center rounded-full text-xs flex-shrink-0">5</span>
                            Data Privacy & Consent
                        </h4>
                        <p>
                            I consent to the collection, processing, and storage of my personal data by Xtenda Finance Limited. I understand and agree that this data may be shared with third parties, including credit bureaus, regulators, and debt collection agencies, strictly for legitimate business purposes related to this loan agreement and as required by Zambian law.
                        </p>
                    </section>
                </div>
                <div className="p-4 border-t bg-gray-50 rounded-b-2xl flex justify-end sticky bottom-0">
                    <button 
                        onClick={onClose}
                        className="bg-green-600 text-white font-bold py-3 px-8 rounded-xl hover:bg-green-700 transition duration-300 flex items-center gap-2"
                    >
                        <i className="fa-solid fa-check"></i>
                        I Understand & Agree
                    </button>
                </div>
            </div>
        </div>
    );
};

const ApplicationForm = ({ loanSummary }: ApplicationFormProps) => {
  const initialFormData: ApplicationFormData = {
    dateOfApplication: new Date().toISOString().split('T')[0],
    fullNames: '', nrc: '', employeeNumber: '', employer: '', phone: '', email: '',
    employmentAddress: '', employmentTerms: 'Permanent', 
    grossSalary: '', netSalary: '',
    loanPurpose: '', 
    selfie: null,
    nrcFront: null, nrcBack: null, latestPayslip: null,
    kinFullNames: '', kinNrc: '', kinRelationship: '', kinPhone: '', kinResidentialAddress: '',
    bankName: '', branchName: '', accountNumber: '',
    declarationAgreed: true,
    signature: '',
  };

  const [formData, setFormData] = React.useState<ApplicationFormData>(initialFormData);
  const [isSubmitted, setIsSubmitted] = React.useState(false);
  const [isPreviewing, setIsPreviewing] = React.useState(false);
  const [showTerms, setShowTerms] = React.useState(false);
  const [hasStartedForm, setHasStartedForm] = React.useState(false);
  const [errors, setErrors] = React.useState<{ [key: string]: string }>({});
  const [draftData, setDraftData] = React.useState<ApplicationFormData | null>(null);

  // Load draft from localStorage on component mount
  React.useEffect(() => {
    try {
        const savedDraft = localStorage.getItem('xtenda_draft_application');
        if (savedDraft) {
            const parsedDraft = JSON.parse(savedDraft);
            // Check if there's meaningful data to restore
            if (parsedDraft.fullNames || parsedDraft.nrc || parsedDraft.phone) {
                setDraftData(parsedDraft);
            }
        }
    } catch (error) {
        console.error("Failed to load draft application:", error);
        localStorage.removeItem('xtenda_draft_application');
    }
  }, []);

  // Auto-save form data to localStorage on change
  React.useEffect(() => {
    // Only save if the user has started filling the form, it's not submitted, and there's no pending draft decision
    if (hasStartedForm && !isSubmitted && !isPreviewing && !draftData) {
        localStorage.setItem('xtenda_draft_application', JSON.stringify(formData));
    }
  }, [formData, hasStartedForm, isSubmitted, isPreviewing, draftData]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    if (!hasStartedForm) {
        setHasStartedForm(true);
        logVisitorEvent('FORM_INTERACTION', 'Started filling application form');
    }
    const { name, value, type } = e.target;
    
    if (errors[name]) {
        setErrors(prev => {
            const newErrors = { ...prev };
            delete newErrors[name];
            return newErrors;
        });
    }

    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleFileChange = React.useCallback((field: keyof ApplicationFormData) => (dataUrl: string | null, fileName: string | null) => {
      setFormData(prev => ({ ...prev, [field]: dataUrl }));
  }, []);

  const handleSelfieCapture = React.useCallback((imageDataUrl: string | null) => {
    setFormData(prev => ({ ...prev, selfie: imageDataUrl }));
  }, []);

  const handleSignatureChange = React.useCallback((signatureDataUrl: string) => {
    setFormData(prev => ({ ...prev, signature: signatureDataUrl }));
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ZMW' }).format(amount);
  };

  const handlePreview = (e: React.FormEvent) => {
    e.preventDefault();
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email)) {
        setErrors({ email: "Please enter a valid email address." });
        return;
    }

    if (!formData.declarationAgreed) {
        alert("You must agree to the Terms and Conditions to proceed.");
        return;
    }
    if (!formData.latestPayslip) {
        alert("Please upload your latest payslip.");
        return;
    }
    if (!formData.selfie) {
        alert("Please take a selfie to verify your identity.");
        return;
    }
    if (!formData.signature) {
        alert("Please sign the application before proceeding.");
        return;
    }
    
    logVisitorEvent('FORM_INTERACTION', 'Previewing application');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setIsPreviewing(true);
  };

  const handleFinalSubmit = async () => {
     const submissionId = Date.now().toString();
     const submission = {
        ...formData,
        loanDetails: loanSummary,
        id: submissionId,
        submittedAt: new Date().toISOString(),
        status: 'New'
    };

    // 1. Save Locally (ensures instant feedback for the user and local admin view)
    try {
        const existingData = localStorage.getItem('xtenda_applications');
        const applications = existingData ? JSON.parse(existingData) : [];
        applications.push(submission);
        localStorage.setItem('xtenda_applications', JSON.stringify(applications));
    } catch (error) {
        console.error("Failed to save application locally:", error);
        alert("Issue saving application locally. Device storage might be full.");
        return; // Stop if local save fails critically
    }

    // 2. Send to Netlify Forms (BACKGROUND PROCESS)
    // This allows you to "receive" them in your Netlify dashboard/email.
    try {
        const netlifyData = new FormData();
        netlifyData.append('form-name', 'xtenda_application');
        netlifyData.append('application_id', submissionId);
        netlifyData.append('full_names', formData.fullNames);
        netlifyData.append('phone', formData.phone);
        netlifyData.append('nrc', formData.nrc);
        netlifyData.append('employer', formData.employer);
        netlifyData.append('net_salary', formData.netSalary || '0');
        netlifyData.append('loan_amount', loanSummary?.amount.toString() || '0');
        netlifyData.append('loan_tenure', loanSummary?.months.toString() || '0');
        netlifyData.append('full_data_json', JSON.stringify(submission, null, 2));
        
        await fetch('/', {
            method: 'POST',
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(netlifyData as any).toString(),
        });

    } catch (error) {
        console.warn("Netlify background submission failed (local save worked):", error);
    }

    // 3. Send WhatsApp Notification via Netlify Function (BACKGROUND PROCESS)
    try {
        // This is a "fire-and-forget" call. We don't await it or handle its response
        // in the UI because the user's submission is already saved. This is a background
        // task for the admin.
        fetch('/.netlify/functions/send-whatsapp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(submission),
        });
    } catch (error) {
        // Log the error for debugging but don't show it to the user.
        console.warn("Dispatching WhatsApp notification failed:", error);
    }

    logVisitorEvent('SUBMISSION', `Application submitted by ${formData.fullNames}`);
    localStorage.removeItem('xtenda_draft_application'); // Clear the draft on successful submission
    setIsSubmitted(true);
    setFormData(initialFormData);
    setIsPreviewing(false);
    setHasStartedForm(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const handleResume = () => {
    if (draftData) {
        setFormData(draftData);
        setDraftData(null);
        setHasStartedForm(true); // Ensure auto-save continues
        logVisitorEvent('FORM_INTERACTION', 'Resumed draft application');
    }
  };

  const handleDiscard = () => {
      if (window.confirm("Are you sure you want to discard your saved progress?")) {
          localStorage.removeItem('xtenda_draft_application');
          setDraftData(null);
          setFormData(initialFormData); // Ensure form is reset
          logVisitorEvent('FORM_INTERACTION', 'Discarded draft application');
      }
  };

  if (isSubmitted) {
    return (
        <section className="my-16 p-8 bg-white rounded-2xl shadow-lg border border-green-100 text-center animate-fade-in">
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-check text-5xl text-green-600"></i>
            </div>
            <h2 className="text-3xl font-extrabold text-gray-800 mb-4">Application Received!</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-md mx-auto">
                Thanks for choosing Xtenda! Our team is reviewing your details and will contact you shortly.
            </p>
            <button
              onClick={() => {
                  localStorage.removeItem('xtenda_draft_application');
                  setIsSubmitted(false);
              }}
              className="bg-orange-500 text-white font-bold py-3 px-10 rounded-full hover:bg-orange-600 transition duration-300 shadow-md"
            >
                Start New Application
            </button>
        </section>
    );
  }

  if (isPreviewing) {
      return (
          <section className="my-8 bg-white rounded-2xl shadow-xl overflow-hidden max-w-4xl mx-auto animate-fade-in">
              <div className="bg-gray-800 text-white p-6 text-center relative">
                  <button onClick={() => setIsPreviewing(false)} className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 hover:text-white flex items-center gap-2">
                      <i className="fa-solid fa-arrow-left"></i> Edit
                  </button>
                  <h2 className="text-2xl font-bold">Confirm Your Details</h2>
              </div>

              <div className="p-6 md:p-10 space-y-8">
                  {loanSummary && loanSummary.amount > 0 && (
                      <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded-r-lg">
                          <h3 className="font-bold text-orange-800 mb-2">Loan Summary</h3>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                              <div><span className="text-gray-500 block">Amount</span><span className="font-bold">{formatCurrency(loanSummary.amount)}</span></div>
                              <div><span className="text-gray-500 block">Period</span><span className="font-bold">{loanSummary.months} Months</span></div>
                              <div><span className="text-gray-500 block">Monthly</span><span className="font-bold">{formatCurrency(loanSummary.monthlyPayment)}</span></div>
                          </div>
                      </div>
                  )}

                  <div className="grid md:grid-cols-2 gap-6">
                      <div>
                          <h3 className="font-bold text-gray-700 border-b pb-2 mb-3">Personal</h3>
                          <ul className="space-y-2 text-sm">
                              <li><span className="text-gray-500">Name:</span> {formData.fullNames}</li>
                              <li><span className="text-gray-500">NRC:</span> {formData.nrc}</li>
                              <li><span className="text-gray-500">Phone:</span> {formData.phone}</li>
                              <li><span className="text-gray-500">Email:</span> {formData.email}</li>
                              <li><span className="text-gray-500">Address:</span> {formData.employmentAddress}</li>
                          </ul>
                      </div>
                      <div>
                          <h3 className="font-bold text-gray-700 border-b pb-2 mb-3">Employment</h3>
                          <ul className="space-y-2 text-sm">
                              <li><span className="text-gray-500">Employer:</span> {formData.employer}</li>
                              <li><span className="text-gray-500">Employee #:</span> {formData.employeeNumber}</li>
                              <li><span className="text-gray-500">Terms:</span> {formData.employmentTerms}</li>
                          </ul>
                      </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                       <div>
                          <h3 className="font-bold text-gray-700 border-b pb-2 mb-3">Bank Details</h3>
                          <ul className="space-y-2 text-sm">
                              <li><span className="text-gray-500">Bank:</span> {formData.bankName}</li>
                              <li><span className="text-gray-500">Branch:</span> {formData.branchName}</li>
                              <li><span className="text-gray-500">Account:</span> {formData.accountNumber}</li>
                          </ul>
                      </div>
                      <div>
                          <h3 className="font-bold text-gray-700 border-b pb-2 mb-3">Next of Kin</h3>
                          <ul className="space-y-2 text-sm">
                              <li><span className="text-gray-500">Name:</span> {formData.kinFullNames}</li>
                              <li><span className="text-gray-500">Relation:</span> {formData.kinRelationship}</li>
                              <li><span className="text-gray-500">Phone:</span> {formData.kinPhone}</li>
                          </ul>
                      </div>
                  </div>

                   <div>
                      <h3 className="font-bold text-gray-700 border-b pb-2 mb-3">Documents</h3>
                      <div className="flex flex-wrap gap-4">
                          <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${formData.selfie ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              <i className={`fa-solid ${formData.selfie ? 'fa-user-check' : 'fa-times-circle'}`}></i>
                              Selfie
                          </div>
                          <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${formData.latestPayslip ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              <i className={`fa-solid ${formData.latestPayslip ? 'fa-check-circle' : 'fa-times-circle'}`}></i>
                              Payslip
                          </div>
                           <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${formData.nrcFront && formData.nrcBack ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                              <i className={`fa-solid ${formData.nrcFront && formData.nrcBack ? 'fa-id-card' : 'fa-minus-circle'}`}></i>
                              NRC
                          </div>
                          <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${formData.signature ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              <i className={`fa-solid ${formData.signature ? 'fa-signature' : 'fa-times-circle'}`}></i>
                              Signature
                          </div>
                      </div>
                  </div>

                  <button
                      onClick={handleFinalSubmit}
                      className="w-full bg-green-600 text-white font-bold py-4 rounded-xl text-xl hover:bg-green-700 transition duration-300 shadow-lg flex items-center justify-center gap-2"
                  >
                      Confirm & Submit Application <i className="fa-solid fa-paper-plane"></i>
                  </button>
              </div>
          </section>
      )
  }

  return (
    <section id="application-form" className="max-w-4xl mx-auto my-12 bg-white p-6 md:p-10 rounded-2xl shadow-xl">
      <TermsModal isOpen={showTerms} onClose={() => setShowTerms(false)} />

      {draftData && (
        <div className="bg-orange-100 border-l-4 border-orange-500 p-4 rounded-r-lg mb-8 flex flex-col sm:flex-row justify-between items-center gap-4 animate-fade-in">
          <div className="flex-grow">
            <h4 className="font-bold text-orange-800 flex items-center gap-2"><i className="fa-solid fa-floppy-disk"></i> Welcome Back!</h4>
            <p className="text-sm text-orange-700 mt-1">You have an unfinished application. Would you like to continue where you left off?</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <button 
                onClick={handleResume} 
                className="bg-green-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-green-700 transition shadow-sm"
            >
                Resume
            </button>
            <button 
                onClick={handleDiscard} 
                className="bg-transparent text-gray-600 font-medium py-2 px-4 rounded-lg hover:bg-orange-200/50 transition"
            >
                Discard
            </button>
          </div>
        </div>
      )}

      <div className="text-center mb-10">
        <h2 className="text-3xl md:text-4xl font-extrabold text-gray-800 mb-3">Loan Application</h2>
        <p className="text-gray-600">Please fill in all required details accurately.</p>
      </div>

      <form onSubmit={handlePreview} className="space-y-10">
        {/* 1. Required Documents */}
        <div>
             <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-file-alt text-orange-500"></i>
              1. Required Documents
            </h3>
            
            <div className="space-y-8">
                
                <div>
                    <h4 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
                        <i className="fa-solid fa-camera"></i>
                        Live Selfie <span className="text-red-500">*</span>
                    </h4>
                    <p className="text-sm text-gray-500 mb-4">Please take a clear photo of your face for identity verification.</p>
                    <CameraCapture onCapture={handleSelfieCapture} />
                </div>

                <div className="border-t pt-6">
                    <FileUpload 
                        label="Latest Payslip (Required)" 
                        fileType="application/pdf,image/*" 
                        onFileSelect={handleFileChange('latestPayslip')} 
                    />
                     {!formData.latestPayslip && <p className="text-xs text-gray-500 mt-1">* Please upload a clearly visible payslip.</p>}
                </div>

                <div className="border-t pt-6">
                    <h4 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
                        <i className="fa-solid fa-id-card"></i>
                        National Registration Card (NRC) <span className="text-sm font-normal text-gray-500 ml-2">(Optional)</span>
                    </h4>
                    <p className="text-sm text-gray-500 mb-4">If available, please <strong>upload or capture</strong> clear images of your NRC (Front and Back) to speed up processing.</p>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <FileUpload 
                                label="NRC Front (Optional)" 
                                fileType="application/pdf,image/*" 
                                onFileSelect={handleFileChange('nrcFront')} 
                            />
                        </div>
                        <div>
                             <FileUpload 
                                label="NRC Back (Optional)" 
                                fileType="application/pdf,image/*" 
                                onFileSelect={handleFileChange('nrcBack')} 
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* 2. Personal Information */}
        <div>
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-user text-orange-500"></i>
              2. Personal Information
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <FormInput label="Full Names" name="fullNames" formData={formData} handleInputChange={handleInputChange} required />
            <FormInput label="NRC Number" name="nrc" formData={formData} handleInputChange={handleInputChange} required placeholder="e.g. 123456/10/1" />
            <FormInput label="Phone Number" name="phone" type="tel" formData={formData} handleInputChange={handleInputChange} required placeholder="e.g. 097xxxxxxx" />
            <FormInput label="Email Address" name="email" type="email" formData={formData} handleInputChange={handleInputChange} required error={errors.email} />
            <div className="md:col-span-2">
                 <FormInput label="Residential Address" name="employmentAddress" formData={formData} handleInputChange={handleInputChange} required />
            </div>
          </div>
        </div>

        {/* 3. Employment Details */}
        <div>
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-briefcase text-orange-500"></i>
              3. Employment Details
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <FormInput label="Current Employer" name="employer" formData={formData} handleInputChange={handleInputChange} required />
            <FormInput label="Employee Number" name="employeeNumber" formData={formData} handleInputChange={handleInputChange} required />
            
            <div>
                <label className="text-sm font-medium text-gray-600 mb-1 block">Employment Terms<span className="text-red-500 ml-1">*</span></label>
                <select
                    name="employmentTerms"
                    required
                    value={formData.employmentTerms}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 bg-white"
                >
                    <option value="Permanent">Permanent</option>
                    <option value="Contract">Contract</option>
                </select>
            </div>

             <div>
                <label htmlFor="loanPurpose" className="text-sm font-medium text-gray-600 mb-1 block">Loan Purpose<span className="text-red-500 ml-1">*</span></label>
                <select
                    id="loanPurpose"
                    name="loanPurpose"
                    required
                    value={formData.loanPurpose}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 bg-white"
                >
                    <option value="">Select a purpose...</option>
                    <option value="School Fees">School Fees</option>
                    <option value="Medical Expenses">Medical Expenses</option>
                    <option value="Home Improvement">Home Improvement</option>
                    <option value="Business Boost">Business Boost</option>
                    <option value="Agricultural Inputs">Agricultural Inputs</option>
                    <option value="Emergency">Emergency</option>
                    <option value="Vehicle Purchase">Vehicle Purchase</option>
                    <option value="Rent/Mortgage Payment">Rent/Mortgage Payment</option>
                    <option value="Buy Land/House">Buy Land/House</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div className="grid grid-cols-2 gap-4 md:col-span-2">
                 <FormInput label="Gross Salary (ZMW)" name="grossSalary" type="number" formData={formData} handleInputChange={handleInputChange} placeholder="e.g. 5000" />
                 <FormInput label="Net Salary (ZMW)" name="netSalary" type="number" formData={formData} handleInputChange={handleInputChange} placeholder="e.g. 4200" />
            </div>

          </div>
        </div>

        {/* 4. Banking & Kin */}
        <div className="grid md:grid-cols-2 gap-10">
             <div>
                <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
                    <i className="fa-solid fa-university text-orange-500"></i>
                    4. Bank Details
                </h3>
                <div className="space-y-6">
                    <FormInput label="Bank Name" name="bankName" formData={formData} handleInputChange={handleInputChange} required />
                    <FormInput label="Branch Name" name="branchName" formData={formData} handleInputChange={handleInputChange} required />
                    <FormInput label="Account Number" name="accountNumber" formData={formData} handleInputChange={handleInputChange} required />
                </div>
             </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
                    <i className="fa-solid fa-users text-orange-500"></i>
                    5. Next of Kin
                </h3>
                <div className="space-y-6">
                    <FormInput label="Full Names" name="kinFullNames" formData={formData} handleInputChange={handleInputChange} required />
                     <div className="grid grid-cols-2 gap-4">
                        <FormInput label="NRC (Optional)" name="kinNrc" formData={formData} handleInputChange={handleInputChange} required={false} />
                        <div>
                            <label htmlFor="kinRelationship" className="text-sm font-medium text-gray-600 mb-1 block">Relationship<span className="text-red-500 ml-1">*</span></label>
                            <select
                                id="kinRelationship"
                                name="kinRelationship"
                                required
                                value={formData.kinRelationship}
                                onChange={handleInputChange}
                                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 bg-white"
                            >
                                <option value="">Select relationship...</option>
                                <option value="Spouse">Spouse</option>
                                <option value="Parent">Parent</option>
                                <option value="Child">Child</option>
                                <option value="Sibling">Sibling</option>
                                <option value="Other relative">Other relative</option>
                                <option value="Friend">Friend</option>
                            </select>
                        </div>
                     </div>
                    <FormInput label="Phone Number" name="kinPhone" type="tel" formData={formData} handleInputChange={handleInputChange} required />
                    <FormInput label="Residential Address" name="kinResidentialAddress" formData={formData} handleInputChange={handleInputChange} required />
                </div>
             </div>
        </div>

        {/* 6. Declaration & Signature */}
        <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
            <h3 className="text-xl font-bold text-gray-800 mb-4">6. Declaration</h3>
            <label className="flex gap-3 items-start cursor-pointer">
                <input
                    type="checkbox"
                    name="declarationAgreed"
                    checked={formData.declarationAgreed}
                    onChange={handleInputChange}
                    required
                    className="mt-1 h-5 w-5 text-orange-600 rounded border-gray-300 focus:ring-orange-500"
                />
                <span className="text-sm text-gray-700 leading-relaxed">
                    I hereby declare that the information provided is true and correct. I have read and agree to the <button type="button" onClick={(e) => { e.preventDefault(); setShowTerms(true); }} className="text-orange-500 underline font-bold hover:text-orange-600">Terms & Conditions</button> regarding loan recovery and data processing.
                </span>
            </label>

            <div className="mt-8">
                <label className="block text-sm font-medium text-gray-700 mb-3">Digital Signature <span className="text-red-500">*</span></label>
                <SignaturePad onSignatureChange={handleSignatureChange} />
            </div>
        </div>

        <button
            type="submit"
            disabled={!formData.declarationAgreed || !formData.signature || !formData.selfie}
            className="w-full bg-orange-500 text-white font-bold py-4 px-8 rounded-full hover:bg-orange-600 transition duration-300 text-lg shadow-lg disabled:bg-gray-300 disabled:cursor-not-allowed transform hover:scale-[1.01]"
        >
            Review Application <i className="fa-solid fa-arrow-right ml-2"></i>
        </button>
      </form>
    </section>
  );
};

export default ApplicationForm;
