export interface ScheduleEntry {
  disbursedAmount: number;
  installments: {
    [key: number]: number;
  };
}

export interface ApplicationFormData {
  id?: string; // Firestore document ID
  dateOfApplication: string;
  fullNames: string;
  nrc: string;
  employeeNumber: string;
  employer: string;
  phone: string;
  email: string;
  employmentAddress: string;
  employmentTerms: string;
  loanPurpose?: string;
  kinFullNames: string;
  kinNrc: string;
  kinRelationship: string;
  kinPhone: string;
  kinResidentialAddress: string;
  bankName: string;
  branchName: string;
  accountNumber: string;
  declarationAgreed: boolean;
  signature: string; // Data URL of the signature image
  nrcImageFront: string; // Data URL of the NRC front image
  nrcImageBack: string; // Data URL of the NRC back image
  latestPayslip: string; // Data URL of the payslip file
  submittedAt?: string;
  status?: 'New' | 'Under Review' | 'Approved' | 'Rejected';
  loanDetails?: {
    amount: number;
    months: number;
    monthlyPayment: number;
  };
  createdAt?: any; // For Firestore server timestamp
  lastModifiedAt?: any; // For Firestore server timestamp
}

export interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
}