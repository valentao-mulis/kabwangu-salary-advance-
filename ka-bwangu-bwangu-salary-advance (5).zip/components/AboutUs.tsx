import React from 'react';

const AboutUs = () => {
  return (
    <section id="about-us" className="max-w-4xl mx-auto my-12 animate-fade-in px-4">
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-extrabold text-gray-800 leading-tight mb-4">
          About <span className="text-orange-500">Xtenda</span> <span className="text-green-600">Zambia</span>
        </h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Your trusted partner for fast, fair, and flexible financial solutions.
        </p>
      </div>

      <div className="space-y-10">
        {/* Our Mission */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col md:flex-row items-center">
          <div className="md:w-1/3 text-center p-8 bg-orange-500 text-white">
            <i className="fa-solid fa-bullseye fa-4x"></i>
          </div>
          <div className="p-8 md:w-2/3">
            <h3 className="text-2xl font-bold text-gray-800 mb-3">Our Mission</h3>
            <p className="text-gray-700 leading-relaxed">
              To empower salaried employees across Zambia by providing immediate and accessible credit solutions. We strive to bridge financial gaps with our "Ka Bwangu Bwangu" service, ensuring our clients can meet their urgent needs with dignity and speed.
            </p>
          </div>
        </div>

        {/* Our Story */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col md:flex-row-reverse items-center">
          <div className="md:w-1/3 text-center p-8 bg-green-600 text-white">
             <i className="fa-solid fa-book-open fa-4x"></i>
          </div>
          <div className="p-8 md:w-2/3">
            <h3 className="text-2xl font-bold text-gray-800 mb-3">Our Story</h3>
            <p className="text-gray-700 leading-relaxed">
              Founded with a deep understanding of the everyday financial challenges faced by Zambians, Xtenda was created to offer a better alternative to traditional lending. We saw the need for a faster, more transparent, and customer-friendly salary advance service. Today, we are proud to have helped thousands of individuals manage their finances with our simple and reliable platform.
            </p>
          </div>
        </div>
        
        {/* Our Values */}
        <div className="bg-white rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Our Core Values</h3>
            <div className="grid md:grid-cols-3 gap-8 text-center">
                <div className="flex flex-col items-center">
                    <div className="bg-orange-100 text-orange-500 w-16 h-16 rounded-full flex items-center justify-center mb-3 text-2xl">
                        <i className="fa-solid fa-bolt"></i>
                    </div>
                    <h4 className="font-bold text-lg mb-1">Speed</h4>
                    <p className="text-gray-600 text-sm">We value your time. Our processes are streamlined for instant decisions and disbursement.</p>
                </div>
                 <div className="flex flex-col items-center">
                    <div className="bg-green-100 text-green-600 w-16 h-16 rounded-full flex items-center justify-center mb-3 text-2xl">
                       <i className="fa-solid fa-handshake-simple"></i>
                    </div>
                    <h4 className="font-bold text-lg mb-1">Integrity</h4>
                    <p className="text-gray-600 text-sm">We operate with complete transparency. No hidden fees, no surprises.</p>
                </div>
                 <div className="flex flex-col items-center">
                    <div className="bg-blue-100 text-blue-500 w-16 h-16 rounded-full flex items-center justify-center mb-3 text-2xl">
                        <i className="fa-solid fa-users"></i>
                    </div>
                    <h4 className="font-bold text-lg mb-1">Customer Focus</h4>
                    <p className="text-gray-600 text-sm">You are at the heart of everything we do. We are committed to your financial well-being.</p>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;