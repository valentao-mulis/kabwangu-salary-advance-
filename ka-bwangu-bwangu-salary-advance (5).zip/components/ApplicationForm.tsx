import React from 'react';
import { ApplicationFormData } from '../types';
import SignaturePad from './SignaturePad';
import CameraCapture from './CameraCapture';
import FileUpload from './FileUpload';
import { firestore } from '../firebaseConfig';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

// Helper to convert a file/blob to a Base64 Data URL
const fileToDataUrl = (file: Blob | File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
};

// Helper to compress an image Data URL
const compressImageDataUrl = (dataUrl: string, quality = 0.85): Promise<string> => {
    return new Promise((resolve, reject) => {
        if (!dataUrl.startsWith('data:image')) {
            resolve(dataUrl); // Don't compress non-images (like PDFs)
            return;
        }

        const img = new Image();
        img.src = dataUrl;
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const MAX_DIMENSION = 1024;
            let { width, height } = img;

            if (width > height) {
                if (width > MAX_DIMENSION) {
                    height = Math.round((height * MAX_DIMENSION) / width);
                    width = MAX_DIMENSION;
                }
            } else {
                if (height > MAX_DIMENSION) {
                    width = Math.round((width * MAX_DIMENSION) / height);
                    height = MAX_DIMENSION;
                }
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                return reject(new Error('Could not get canvas context'));
            }
            ctx.drawImage(img, 0, 0, width, height);
            const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
            resolve(compressedDataUrl);
        };
        img.onerror = (error) => reject(error);
    });
};


const ApplicationForm = ({ loanSummary }: {
    loanSummary?: {
        amount: number;
        months: number;
        monthlyPayment: number;
    };
}) => {
  const initialFormData: Omit<ApplicationFormData, 'signature' | 'nrcImageFront' | 'nrcImageBack' | 'latestPayslip' | 'id' | 'createdAt' | 'lastModifiedAt'> = {
    dateOfApplication: new Date().toISOString().split('T')[0],
    fullNames: '', nrc: '', employeeNumber: '', employer: '', phone: '', email: '',
    employmentAddress: '', employmentTerms: 'Permanent', loanPurpose: '',
    kinFullNames: '', kinNrc: '', kinRelationship: '', kinPhone: '', kinResidentialAddress: '',
    bankName: '', branchName: '', accountNumber: '',
    declarationAgreed: true,
  };

  const [formData, setFormData] = React.useState<Partial<ApplicationFormData>>(initialFormData);
  const [signatureBlob, setSignatureBlob] = React.useState<Blob | null>(null);
  const [nrcFrontBlob, setNrcFrontBlob] = React.useState<Blob | null>(null);
  const [nrcBackBlob, setNrcBackBlob] = React.useState<Blob | null>(null);
  const [payslipFile, setPayslipFile] = React.useState<File | null>(null);

  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submissionError, setSubmissionError] = React.useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.currentTarget as HTMLFormElement;
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    setIsSubmitting(true);
    setSubmissionError('');

    try {
        // 1. Convert all files to compressed Data URLs in parallel
        const [signature, nrcImageFront, nrcImageBack, latestPayslip] = await Promise.all([
            signatureBlob ? compressImageDataUrl(await fileToDataUrl(signatureBlob)) : '',
            nrcFrontBlob ? compressImageDataUrl(await fileToDataUrl(nrcFrontBlob)) : '',
            nrcBackBlob ? compressImageDataUrl(await fileToDataUrl(nrcBackBlob)) : '',
            payslipFile ? fileToDataUrl(payslipFile) : '',
        ]);
        
        // 2. Prepare the final document
        const finalData = {
            ...formData,
            loanDetails: loanSummary,
            signature,
            nrcImageFront,
            nrcImageBack,
            latestPayslip,
            status: 'New' as const,
            submittedAt: new Date().toISOString(),
            createdAt: serverTimestamp(),
            lastModifiedAt: serverTimestamp(),
        };

        // 3. Save everything in a single Firestore call
        const docRef = await addDoc(collection(firestore, 'applications'), finalData);

        // 4. Redirect the user for an "instant" experience.
        window.location.href = `/?applicationId=${docRef.id}`;

    } catch (error) {
      console.error("Submission failed:", error);
      setSubmissionError("Submission failed. Please check your connection and try again.");
      setIsSubmitting(false);
    }
  };

  return (
    <section id="application-form" className="max-w-4xl mx-auto my-12 bg-white p-6 md:p-10 rounded-2xl shadow-xl px-4">
      <div className="text-center mb-10">
        <h2 className="text-3xl md:text-4xl font-extrabold text-gray-800 mb-3">Loan Application</h2>
        <p className="text-gray-600">Please fill in your details. Fields marked with <span className="text-red-500">*</span> are required.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-10" noValidate>
        
        <div>
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-user text-orange-500"></i>
              Personal Information
          </h3>
          <div className="grid md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
              <label htmlFor="fullNames" className="block text-sm font-medium text-gray-700 mb-1">Full Names<span className="text-red-500 ml-1">*</span></label>
              <input id="fullNames" type="text" name="fullNames" placeholder="As per your NRC" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
             <div>
              <label htmlFor="nrc" className="block text-sm font-medium text-gray-700 mb-1">NRC Number<span className="text-red-500 ml-1">*</span></label>
              <input id="nrc" type="text" name="nrc" placeholder="e.g. 123456/10/1" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
             <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">Phone Number<span className="text-red-500 ml-1">*</span></label>
              <input id="phone" type="tel" name="phone" placeholder="e.g. 097..." required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
             <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address<span className="text-red-500 ml-1">*</span></label>
              <input id="email" type="email" name="email" placeholder="e.g. name@example.com" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="employmentAddress" className="block text-sm font-medium text-gray-700 mb-1">Residential Address<span className="text-red-500 ml-1">*</span></label>
              <input id="employmentAddress" type="text" name="employmentAddress" placeholder="Your current residential address" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-briefcase text-orange-500"></i>
              Employment Details
          </h3>
          <div className="grid md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
                <label htmlFor="employer" className="block text-sm font-medium text-gray-700 mb-1">Current Employer</label>
                <input id="employer" type="text" name="employer" placeholder="Name of your employer" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div>
                <label htmlFor="employeeNumber" className="block text-sm font-medium text-gray-700 mb-1">Employee Number</label>
                <input id="employeeNumber" type="text" name="employeeNumber" placeholder="Your staff ID" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
             <div>
                <label htmlFor="employmentTerms" className="block text-sm font-medium text-gray-700 mb-1">Employment Terms</label>
                <select id="employmentTerms" name="employmentTerms" onChange={handleInputChange} className="w-full p-3 border rounded-lg bg-white">
                    <option value="Permanent">Permanent</option>
                    <option value="Contract">Contract</option>
                </select>
            </div>
            <div>
                <label htmlFor="loanPurpose" className="block text-sm font-medium text-gray-700 mb-1">Loan Purpose</label>
                <input id="loanPurpose" type="text" name="loanPurpose" placeholder="e.g. School Fees" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-university text-orange-500"></i>
              Bank Details
          </h3>
          <div className="grid md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
                <label htmlFor="bankName" className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
                <input id="bankName" type="text" name="bankName" placeholder="e.g. Zanaco" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div>
                <label htmlFor="branchName" className="block text-sm font-medium text-gray-700 mb-1">Branch Name</label>
                <input id="branchName" type="text" name="branchName" placeholder="e.g. Manda Hill" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div className="md:col-span-2">
                <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
                <input id="accountNumber" type="text" name="accountNumber" placeholder="Your bank account number" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-users text-orange-500"></i>
              Next of Kin
          </h3>
          <div className="grid md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
                <label htmlFor="kinFullNames" className="block text-sm font-medium text-gray-700 mb-1">Kin's Full Names<span className="text-red-500 ml-1">*</span></label>
                <input id="kinFullNames" type="text" name="kinFullNames" placeholder="Full names of your next of kin" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div>
                <label htmlFor="kinRelationship" className="block text-sm font-medium text-gray-700 mb-1">Relationship<span className="text-red-500 ml-1">*</span></label>
                <select id="kinRelationship" name="kinRelationship" defaultValue="" required onChange={handleInputChange} className="w-full p-3 border rounded-lg bg-white">
                    <option value="" disabled>-- Select --</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Parent">Parent</option>
                    <option value="Sibling">Sibling</option>
                    <option value="Child">Child</option>
                    <option value="Other Relative">Other Relative</option>
                </select>
            </div>
            <div>
                <label htmlFor="kinPhone" className="block text-sm font-medium text-gray-700 mb-1">Kin's Phone Number<span className="text-red-500 ml-1">*</span></label>
                <input id="kinPhone" type="tel" name="kinPhone" placeholder="Next of kin's phone" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div>
                <label htmlFor="kinNrc" className="block text-sm font-medium text-gray-700 mb-1">Kin's NRC Number</label>
                <input id="kinNrc" type="text" name="kinNrc" placeholder="Next of kin's NRC" onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
            <div className="md:col-span-2">
                <label htmlFor="kinResidentialAddress" className="block text-sm font-medium text-gray-700 mb-1">Kin's Residential Address<span className="text-red-500 ml-1">*</span></label>
                <input id="kinResidentialAddress" type="text" name="kinResidentialAddress" placeholder="Next of kin's address" required onChange={handleInputChange} className="w-full p-3 border rounded-lg" />
            </div>
          </div>
        </div>

        <div>
            <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
                <i className="fa-solid fa-paperclip text-orange-500"></i>
                Attachments
            </h3>
            <div className="space-y-8">
                <div id="nrc-section" className="grid md:grid-cols-2 gap-x-8 gap-y-8">
                    <CameraCapture title="NRC (Front)" onCapture={setNrcFrontBlob} guideType="nrc" />
                    <CameraCapture title="NRC (Back)" onCapture={setNrcBackBlob} guideType="nrc" />
                </div>
                <div id="payslip-section">
                    <FileUpload label="Latest Payslip" fileType="application/pdf,image/*" onFileSelect={setPayslipFile} />
                </div>
            </div>
        </div>
        
        <div id="signature-section">
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 border-b pb-3 mb-6">
              <i className="fa-solid fa-signature text-orange-500"></i>
              Declaration & Signature
          </h3>
           <div className="space-y-4 bg-gray-50 p-4 rounded-lg border">
                <p className="text-xs text-gray-600">
                    I, the undersigned, hereby declare that the information provided is true and correct. I authorize Xtenda to verify this information and agree to the terms and conditions.
                </p>
                <div className="flex items-start">
                    <input id="declarationAgreed" name="declarationAgreed" type="checkbox" defaultChecked={true} onChange={handleInputChange} className="h-4 w-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500 mt-1" />
                    <label htmlFor="declarationAgreed" className="ml-3 block text-sm font-medium text-gray-700">I agree to the declaration above.</label>
                </div>
            </div>
            <div className="mt-6">
                <label className="text-sm font-medium text-gray-600 mb-2 block">Please sign in the box below</label>
                <SignaturePad onSignatureChange={setSignatureBlob} />
            </div>
        </div>
        
        <div className="mt-12 pt-8 border-t-2 border-dashed">
            <button type="submit" disabled={isSubmitting} className="w-full bg-green-600 text-white font-extrabold py-4 px-6 rounded-xl hover:bg-green-700 transition duration-300 text-xl shadow-lg flex items-center justify-center gap-3 disabled:bg-gray-400 disabled:cursor-not-allowed">
                {isSubmitting ? (
                    <>
                        <i className="fa-solid fa-spinner fa-spin"></i> Submitting...
                    </>
                ) : (
                     <>
                        Submit Application <i className="fa-solid fa-paper-plane"></i>
                     </>
                )}
            </button>
            {submissionError && (
                <p className="text-red-600 text-center font-semibold mt-4">{submissionError}</p>
            )}
        </div>

      </form>
    </section>
  );
};

export default ApplicationForm;