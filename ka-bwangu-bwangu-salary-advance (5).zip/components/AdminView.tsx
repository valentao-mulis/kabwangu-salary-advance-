import React from 'react';
import AdminChatbot from './AdminChatbot';
import { firestore } from '../firebaseConfig';
import { doc, updateDoc } from 'firebase/firestore';

interface AdminViewProps {
    data: any;
    onBack?: () => void;
}

const AdminView = ({ data, onBack }: AdminViewProps) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editableData, setEditableData] = React.useState(data);
  const [saveMessage, setSaveMessage] = React.useState<{text: string, type: 'success'|'error'} | null>(null);
  
  // Update local state when data prop changes (e.g. when switching between apps)
  React.useEffect(() => {
      setEditableData(data);
      setIsEditing(false);
      setSaveMessage(null);
  }, [data]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditableData((prev: any) => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
      try {
          const docRef = doc(firestore, 'applications', editableData.id);
          const dataToSave = { ...editableData };
          delete dataToSave.id; // Don't save the ID field back into the document
          await updateDoc(docRef, dataToSave);
          
          setIsEditing(false);
          setSaveMessage({ text: "Application updated successfully.", type: 'success' });
          
          setTimeout(() => setSaveMessage(null), 3000);
      } catch (error) {
          console.error("Failed to save application:", error);
          setSaveMessage({ text: "Failed to save changes. Please try again.", type: 'error' });
      }
  };
  
  const handleCancel = () => {
    setEditableData(data); // Revert to original data
    setIsEditing(false);
    setSaveMessage(null);
  };

  const renderField = (label: string, fieldName: string, type = 'text') => {
    const value = editableData[fieldName];
    let content;

    if (isEditing) {
        if (fieldName === 'employmentTerms') {
            content = (
                 <select name={fieldName} value={value || 'Permanent'} 
                    // FIX: Changed `onChange={isEditing}` to `onChange={handleInputChange}`
                    onChange={handleInputChange} 
                    className="w-full p-2 border rounded-lg bg-white">
                     <option value="Permanent">Permanent</option>
                     <option value="Contract">Contract</option>
                 </select>
            );
        } else if (fieldName === 'status') {
             content = (
                 <select name={fieldName} value={value || 'New'} onChange={handleInputChange} className="w-full p-2 border rounded-lg bg-white">
                     <option value="New">New</option>
                     <option value="Under Review">Under Review</option>
                     <option value="Approved">Approved</option>
                     <option value="Rejected">Rejected</option>
                 </select>
            );
        } else {
            content = (
                <input
                    type={type}
                    name={fieldName}
                    value={value || ''}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded-lg"
                    disabled={typeof value !== 'string' && typeof value !== 'number'} // Don't edit non-string fields
                />
            );
        }
    } else {
        content = <p className="text-gray-900 font-medium break-words">{value || <span className="text-gray-400">Not Provided</span>}</p>;
        if (fieldName === 'status') {
            const colors = {
                'New': 'bg-blue-100 text-blue-800',
                'Under Review': 'bg-yellow-100 text-yellow-800',
                'Approved': 'bg-green-100 text-green-800',
                'Rejected': 'bg-red-100 text-red-800',
            };
            content = <span className={`px-3 py-1 text-sm font-semibold rounded-full ${colors[value as keyof typeof colors] || 'bg-gray-100 text-gray-800'}`}>{value}</span>
        }
    }

    return (
        <div className="py-4 border-b">
            <p className="text-sm font-semibold text-gray-600 mb-1">{label}</p>
            {content}
        </div>
    );
  };

  const renderAttachment = (label: string, dataUrl: string) => {
      if (!dataUrl) return renderField(label, 'Not Provided');
      
      if (dataUrl.startsWith('data:image')) {
          return (
             <div className="py-4 border-b">
                <p className="text-sm font-semibold text-gray-600 mb-1">{label}</p>
                <a href={dataUrl} target="_blank" rel="noopener noreferrer">
                    <img src={dataUrl} alt={label} className="max-h-60 border rounded bg-gray-50 p-1 cursor-pointer hover:shadow-lg transition-shadow" />
                </a>
            </div>
          );
      }
      
      if (dataUrl.startsWith('data:application/pdf')) {
          return (
              <div className="py-4 border-b">
                <p className="text-sm font-semibold text-gray-600 mb-1">{label}</p>
                <a href={dataUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline font-medium flex items-center gap-2">
                    View Payslip (PDF) <i className="fa-solid fa-external-link-alt text-xs"></i>
                </a>
            </div>
          );
      }
      
      return renderField(label, 'Unsupported file format');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8 font-sans">
      <div className="max-w-4xl mx-auto">
        <header className="flex justify-between items-center mb-6">
            <button onClick={onBack} className="text-gray-600 hover:text-gray-900 flex items-center gap-2">
                <i className="fa-solid fa-arrow-left"></i> Back to Dashboard
            </button>
            
            <div>
            {isEditing ? (
                <div className="flex gap-4">
                    <button onClick={handleCancel} className="bg-gray-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-700">Cancel</button>
                    <button onClick={handleSave} className="bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700">Save Changes</button>
                </div>
            ) : (
                <button onClick={() => setIsEditing(true)} className="bg-orange-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-orange-600 flex items-center gap-2">
                    <i className="fa-solid fa-pencil"></i> Edit
                </button>
            )}
            </div>
        </header>

        {saveMessage && (
            <div className={`p-4 rounded-lg mb-6 text-center font-bold ${saveMessage.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-700'}`}>
                {saveMessage.text}
            </div>
        )}

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 border-b bg-gray-50">
                <h2 className="text-2xl font-bold text-gray-800">Application Details</h2>
                <p className="text-gray-500">Submitted on: {data.submittedAt ? new Date(data.submittedAt).toLocaleString() : 'N/A'}</p>
            </div>

            <div className="p-6 grid md:grid-cols-2 gap-x-8">
                <div>
                    <h3 className="text-lg font-bold text-orange-600 mt-4 mb-2 border-b pb-2">Personal & Contact</h3>
                    {renderField('Full Names', 'fullNames')}
                    {renderField('NRC Number', 'nrc')}
                    {renderField('Phone Number', 'phone')}
                    {renderField('Email Address', 'email')}
                    {renderField('Residential Address', 'employmentAddress')}
                </div>
                <div>
                    <h3 className="text-lg font-bold text-orange-600 mt-4 mb-2 border-b pb-2">Employment & Loan</h3>
                    {renderField('Employer', 'employer')}
                    {renderField('Employee Number', 'employeeNumber')}
                    {renderField('Employment Terms', 'employmentTerms')}
                    {renderField('Loan Amount', `K${data.loanDetails?.amount || 0}`)}
                    {renderField('Repayment Months', data.loanDetails?.months || 0)}
                    {renderField('Monthly Payment', `K${data.loanDetails?.monthlyPayment?.toFixed(2) || 0}`)}
                </div>
                 <div>
                    <h3 className="text-lg font-bold text-orange-600 mt-4 mb-2 border-b pb-2">Bank Details</h3>
                    {renderField('Bank Name', 'bankName')}
                    {renderField('Branch Name', 'branchName')}
                    {renderField('Account Number', 'accountNumber')}
                </div>
                <div>
                    <h3 className="text-lg font-bold text-orange-600 mt-4 mb-2 border-b pb-2">Next of Kin</h3>
                    {renderField("Kin's Full Names", 'kinFullNames')}
                    {renderField("Kin's NRC", 'kinNrc')}
                    {renderField("Kin's Phone", 'kinPhone')}
                    {renderField("Relationship", 'kinRelationship')}
                    {renderField("Kin's Address", 'kinResidentialAddress')}
                </div>
                <div className="md:col-span-2">
                    <h3 className="text-lg font-bold text-orange-600 mt-4 mb-2 border-b pb-2">Status & Attachments</h3>
                    {renderField('Application Status', 'status')}
                    {renderAttachment('NRC (Front)', data.nrcImageFront)}
                    {renderAttachment('NRC (Back)', data.nrcImageBack)}
                    {renderAttachment('Latest Payslip', data.latestPayslip)}
                    {renderAttachment('Signature', data.signature)}
                </div>
            </div>
        </div>
      </div>
      <AdminChatbot applicationData={data} />
    </div>
  );
};

// FIX: Added missing default export
export default AdminView;