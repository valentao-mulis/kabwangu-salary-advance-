import React from 'react';
import { firestore } from '../firebaseConfig';
import { doc, onSnapshot } from 'firebase/firestore';
import { ApplicationFormData } from '../types';

interface SubmissionStatusProps {
    applicationId: string;
}

const StatusDisplayConfig = {
    'New': {
        icon: 'fa-solid fa-paper-plane',
        color: 'blue',
        title: 'Application Received',
        message: "We've successfully received your application. Our team will begin reviewing it shortly."
    },
    'Under Review': {
        icon: 'fa-solid fa-magnifying-glass',
        color: 'yellow',
        title: 'Under Review',
        message: "Your application is currently being reviewed by our team. We're checking the details you provided."
    },
    'Approved': {
        icon: 'fa-solid fa-circle-check',
        color: 'green',
        title: 'Loan Approved!',
        message: 'Congratulations! Your salary advance has been approved. The funds will be disbursed to your account shortly.'
    },
    'Rejected': {
        icon: 'fa-solid fa-circle-xmark',
        color: 'red',
        title: 'Application Declined',
        message: 'After careful consideration, we are unable to approve your application at this time. Please contact us for more details.'
    }
};

const SubmissionStatus = ({ applicationId }: SubmissionStatusProps) => {
    const [application, setApplication] = React.useState<ApplicationFormData | null>(null);
    const [error, setError] = React.useState<string | null>(null);

    React.useEffect(() => {
        const docRef = doc(firestore, 'applications', applicationId);
        const unsubscribe = onSnapshot(docRef, (docSnap) => {
            if (docSnap.exists()) {
                setApplication({ id: docSnap.id, ...docSnap.data() } as ApplicationFormData);
                setError(null);
            } else {
                setError("We couldn't find an application with this ID. It may have been deleted or the link is incorrect.");
                setApplication(null);
            }
        }, (err) => {
            console.error("Error fetching application status:", err);
            setError("There was a problem fetching your application status. Please check your connection and try again.");
        });

        // Cleanup listener on unmount
        return () => unsubscribe();
    }, [applicationId]);

    const handleNewApplication = () => {
        // Navigate to the home page by removing the query parameter
        window.location.href = '/';
    };

    const handleReviewSubmission = () => {
        const currentUrl = new URL(window.location.href);
        currentUrl.searchParams.set('review', 'true');
        window.history.pushState({}, '', currentUrl.toString());
        // Force a re-render by simulating a navigation event that our main App component will catch.
        // A proper router would handle this more gracefully.
        window.dispatchEvent(new PopStateEvent('popstate'));
        window.location.reload();
    };

    const renderContent = () => {
        if (!application && !error) {
             return (
                <div className="text-center py-20">
                    <i className="fa-solid fa-circle-notch fa-spin text-5xl text-gray-300 mb-4"></i>
                    <p className="text-xl text-gray-600">Loading Application Status...</p>
                </div>
            );
        }
        
        if (error) {
            return (
                <div className="text-center py-20">
                    <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <i className="fas fa-exclamation-triangle text-5xl text-red-500"></i>
                    </div>
                    <h2 className="text-3xl font-extrabold text-gray-800 mb-4">Error</h2>
                    <p className="text-xl text-gray-600 mb-8 max-w-md mx-auto">{error}</p>
                </div>
            );
        }

        if (application) {
            const statusKey = application.status || 'New';
            const config = StatusDisplayConfig[statusKey];
            const colorClasses = {
                'blue': { bg: 'bg-blue-100', text: 'text-blue-600', border: 'border-blue-200' },
                'yellow': { bg: 'bg-yellow-100', text: 'text-yellow-600', border: 'border-yellow-200' },
                'green': { bg: 'bg-green-100', text: 'text-green-600', border: 'border-green-200' },
                'red': { bg: 'bg-red-100', text: 'text-red-600', border: 'border-red-200' },
            }[config.color];


            return (
                 <div className="text-center">
                    <div className={`w-24 h-24 ${colorClasses.bg} rounded-full flex items-center justify-center mx-auto mb-6 animate-fade-in`}>
                        <i className={`${config.icon} text-5xl ${colorClasses.text}`}></i>
                    </div>
                    <h2 className="text-3xl font-extrabold text-gray-800 mb-4">{config.title}</h2>
                    <p className="text-lg text-gray-600 mb-8 max-w-lg mx-auto">
                        {config.message}
                    </p>
                    <div className={`p-4 ${colorClasses.bg} border-t-4 ${colorClasses.border} rounded-lg`}>
                        <p className="text-sm text-gray-500">Applicant:</p>
                        <p className="font-bold text-gray-800 text-lg">{application.fullNames}</p>
                        <p className="text-xs text-gray-400 mt-2">Application ID: {application.id}</p>
                    </div>
                     <div className="mt-8">
                        <button
                            onClick={handleReviewSubmission}
                            className="text-sm text-gray-600 hover:text-orange-600 font-semibold underline disabled:text-gray-400 disabled:no-underline disabled:cursor-not-allowed"
                        >
                            Review My Submission Details
                        </button>
                    </div>
                </div>
            );
        }
        
        return null;
    };


    return (
        <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center p-4">
             <section className="my-16 p-8 bg-white rounded-2xl shadow-xl border border-gray-100 w-full max-w-2xl animate-fade-in">
                {renderContent()}
                 <div className="mt-12 text-center border-t pt-8">
                    <button
                      onClick={handleNewApplication}
                      className="bg-orange-500 text-white font-bold py-3 px-10 rounded-full hover:bg-orange-600 transition duration-300 shadow-md"
                    >
                        Start New Application
                    </button>
                 </div>
             </section>
        </div>
    );
};

export default SubmissionStatus;