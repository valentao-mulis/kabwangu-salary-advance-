import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// This configuration now points to your Firebase project.
const firebaseConfig = {
  apiKey: "AIzaSyAIgtz5-MuVWu5xjnnkkkKCxKTg2OsfEXY",
  authDomain: "my-salary-app-78a41.firebaseapp.com",
  projectId: "my-salary-app-78a41",
  storageBucket: "my-salary-app-78a41.firebasestorage.app",
  messagingSenderId: "921078883023",
  appId: "1:921078883023:web:466421b79ed3c793a2cdba"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const firestore = getFirestore(app);

export { firestore };