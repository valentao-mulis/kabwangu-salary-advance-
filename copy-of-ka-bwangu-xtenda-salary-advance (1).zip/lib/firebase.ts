import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAIgtz5-MuVWu5xjnnkkkKCxKTg2OsfEXY",
  authDomain: "my-salary-app-78a41.firebaseapp.com",
  projectId: "my-salary-app-78a41",
  storageBucket: "my-salary-app-78a41.firebasestorage.app",
  messagingSenderId: "921078883023",
  appId: "1:921078883023:web:d52e89cda16152c1a2cdba"
};

// Initialize Firebase
let app;
let db: any;
let storage: any;

try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    storage = getStorage(app);
    console.log("Firebase initialized successfully");
} catch (error) {
    console.error("Error initializing Firebase. Please check your configuration.", error);
}

export { db, storage };