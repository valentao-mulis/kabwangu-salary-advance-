import React from 'react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, deleteDoc, doc, getDocs } from 'firebase/firestore';

interface AdminDashboardProps {
    onSelectApplication: (app: any) => void;
    onExitAdmin: () => void;
}

const AdminDashboard = ({ onSelectApplication, onExitAdmin }: AdminDashboardProps) => {
  const [applications, setApplications] = React.useState<any[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    // Setup real-time listener for applications
    if (!db) {
        setError("Database not configured. Please check lib/firebase.ts");
        setIsLoading(false);
        return;
    }

    setIsLoading(true);
    const q = query(collection(db, "applications"), orderBy("submittedAt", "desc"));
    
    // onSnapshot provides real-time updates automatically
    const unsubscribe = onSnapshot(q, 
        (querySnapshot) => {
            const apps: any[] = [];
            querySnapshot.forEach((doc) => {
                apps.push({ id: doc.id, ...doc.data() });
            });
            setApplications(apps);
            setIsLoading(false);
            setError(null);
        },
        (err) => {
            console.error("Error fetching applications:", err);
            // Provide a helpful error message if it's likely a permission issue
            if (err.code === 'permission-denied') {
                setError("Access denied. Please check your Firebase Firestore Security Rules.");
            } else {
                setError("Failed to load applications. Please check your connection.");
            }
            setIsLoading(false);
        }
    );

    // Cleanup listener on unmount
    return () => unsubscribe();
  }, []);

  const handleDelete = async (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (!db) return;
      if (window.confirm("Are you sure you want to delete this application from the CLOUD? This cannot be undone.")) {
          try {
              await deleteDoc(doc(db, "applications", id));
              // UI updates automatically thanks to onSnapshot
          } catch (err) {
              console.error("Error deleting document:", err);
              alert("Failed to delete application. You might not have permission.");
          }
      }
  };

  // Manual refresh if needed, though onSnapshot handles it mostly
  const handleRefresh = async () => {
      if (!db) return;
      setIsLoading(true);
      try {
          const q = query(collection(db, "applications"), orderBy("submittedAt", "desc"));
          const querySnapshot = await getDocs(q);
          const apps: any[] = [];
          querySnapshot.forEach((doc) => {
              apps.push({ id: doc.id, ...doc.data() });
          });
          setApplications(apps);
          setError(null);
      } catch (err: any) {
           console.error("Manual refresh error:", err);
           setError("Refresh failed: " + err.message);
      } finally {
          setIsLoading(false);
      }
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8 font-sans">
      <div className="max-w-6xl mx-auto">
        <header className="flex justify-between items-center mb-8 bg-white p-6 rounded-xl shadow-md">
            <div>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
                    <span className="text-orange-500">Xtenda</span> Cloud Admin
                </h1>
                <p className="text-gray-500 mt-1">
                    <i className="fa-solid fa-cloud text-blue-500 mr-2"></i>
                    Live Application Dashboard
                </p>
            </div>
            <button 
                onClick={onExitAdmin} 
                className="bg-gray-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-700 transition flex items-center gap-2"
            >
                <i className="fa-solid fa-right-from-bracket"></i> Exit
            </button>
        </header>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 border-b flex justify-between items-center bg-gray-50">
                <h2 className="text-xl font-bold text-gray-700 flex items-center gap-2">
                    Submitted Applications
                    <span className="bg-orange-100 text-orange-700 text-sm px-3 py-1 rounded-full">{applications.length}</span>
                </h2>
                <button onClick={handleRefresh} disabled={isLoading} className="text-blue-600 hover:text-blue-800 transition flex items-center gap-2 disabled:opacity-50">
                    <i className={`fa-solid fa-sync ${isLoading ? 'fa-spin' : ''}`}></i> Refresh
                </button>
            </div>

            {error && (
                <div className="p-6 bg-red-50 text-red-700 border-b border-red-100 flex items-center gap-3">
                    <i className="fa-solid fa-triangle-exclamation text-2xl"></i>
                    <div>
                        <p className="font-bold">Connection Error</p>
                        <p>{error}</p>
                    </div>
                </div>
            )}
            
            {isLoading && !error ? (
                <div className="p-12 text-center text-gray-500">
                     <i className="fa-solid fa-circle-notch fa-spin fa-3x text-orange-400 mb-4"></i>
                     <p>Connecting to live database...</p>
                </div>
            ) : applications.length === 0 && !error ? (
                <div className="p-12 text-center text-gray-500">
                    <i className="fa-solid fa-inbox fa-4x mb-4 text-gray-300"></i>
                    <p className="text-xl">No applications received yet.</p>
                </div>
            ) : (
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead className="bg-gray-100 border-b-2 border-gray-200">
                            <tr>
                                <th className="px-6 py-4 font-semibold text-gray-600 uppercase text-xs tracking-wider">Date Received</th>
                                <th className="px-6 py-4 font-semibold text-gray-600 uppercase text-xs tracking-wider">Status</th>
                                <th className="px-6 py-4 font-semibold text-gray-600 uppercase text-xs tracking-wider">Applicant</th>
                                <th className="px-6 py-4 font-semibold text-gray-600 uppercase text-xs tracking-wider hidden md:table-cell">Employer</th>
                                <th className="px-6 py-4 font-semibold text-gray-600 uppercase text-xs tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {applications.map((app) => (
                                <tr 
                                    key={app.id} 
                                    onClick={() => onSelectApplication(app)}
                                    className="hover:bg-orange-50 cursor-pointer transition duration-150 ease-in-out"
                                >
                                    <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                                        {new Date(app.submittedAt).toLocaleDateString()}
                                        <div className="text-xs text-gray-400 mt-1">
                                            {new Date(app.submittedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            ${app.status === 'New' ? 'bg-green-100 text-green-800' : 
                                              app.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                                              app.status === 'Rejected' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}`}>
                                            {app.status || 'New'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 font-medium text-gray-900">{app.fullNames}</td>
                                    <td className="px-6 py-4 text-gray-600 hidden md:table-cell">{app.employer}</td>
                                    <td className="px-6 py-4 text-right space-x-4">
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); onSelectApplication(app); }} 
                                            className="text-blue-600 hover:text-blue-900 font-medium text-sm"
                                        >
                                            OPEN
                                        </button>
                                        <button 
                                            onClick={(e) => handleDelete(app.id, e)} 
                                            className="text-gray-400 hover:text-red-600 transition"
                                            title="Delete from Cloud"
                                        >
                                            <i className="fa-solid fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;