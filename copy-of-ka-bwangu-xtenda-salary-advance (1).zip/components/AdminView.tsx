import React from 'react';
import AdminChatbot from './AdminChatbot';
import { db } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';

interface AdminViewProps {
    data: any;
    onBack?: () => void;
}

const AdminView = ({ data, onBack }: AdminViewProps) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editableData, setEditableData] = React.useState(data);
  const [saveMessage, setSaveMessage] = React.useState<{text: string, type: 'success'|'error'} | null>(null);
  const [errors, setErrors] = React.useState<{[key: string]: string}>({});
  const [isSaving, setIsSaving] = React.useState(false);

  React.useEffect(() => {
      setEditableData(data);
      setIsEditing(false);
      setSaveMessage(null);
      setErrors({});
  }, [data]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditableData((prev: any) => ({ ...prev, [name]: value }));
    if (errors[name]) {
        setErrors(prev => {
            const newErrors = { ...prev };
            delete newErrors[name];
            return newErrors;
        });
    }
  };

  const validate = () => {
      const newErrors: {[key: string]: string} = {};
      if (!editableData.fullNames?.trim()) newErrors.fullNames = "Full Name is required.";
      if (!editableData.nrc?.trim()) newErrors.nrc = "NRC is required.";
      if (!editableData.phone?.trim()) newErrors.phone = "Phone is required.";
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
      if (!validate()) {
          setSaveMessage({ text: "Validation failed. Check fields.", type: 'error' });
          return;
      }

      if (!db) {
          setSaveMessage({ text: "Database error: Not configured.", type: 'error' });
          return;
      }

      setIsSaving(true);
      try {
          // Update document in Firestore
          const appRef = doc(db, "applications", editableData.id);
          
          // Create a clean object to save, excluding UI specific fields if any exist
          const dataToSave = { ...editableData };
          // Ensure we don't overwrite the ID with itself as a field
          delete dataToSave.id; 

          await updateDoc(appRef, dataToSave);
          
          setIsEditing(false);
          setSaveMessage({ text: "Saved to cloud successfully.", type: 'success' });
          setTimeout(() => setSaveMessage(null), 3000);
      } catch (error: any) {
          console.error("Failed to save to cloud:", error);
          setSaveMessage({ text: "Save failed: " + error.message, type: 'error' });
      } finally {
          setIsSaving(false);
      }
  };
  
  const handleCancel = () => {
    setEditableData(data);
    setIsEditing(false);
    setSaveMessage(null);
    setErrors({});
  };

  const renderField = (label: string, fieldName: string, type = 'text') => {
    const value = editableData[fieldName];
    const error = errors[fieldName];
    let content;

    if (isEditing && type !== 'readonly') {
        if (type === 'radio') {
            content = (
                <div className="flex gap-4 mt-1">
                    <label className="flex items-center"><input type="radio" name={fieldName} value="Permanent" onChange={handleInputChange} checked={value === 'Permanent'} className="mr-2 h-4 w-4"/>Permanent</label>
                    <label className="flex items-center"><input type="radio" name={fieldName} value="Contract" onChange={handleInputChange} checked={value === 'Contract'} className="mr-2 h-4 w-4"/>Contract</label>
                </div>
            );
        } else if (type === 'checkbox') {
            content = (
                <input
                    type="checkbox"
                    name={fieldName}
                    checked={!!value}
                    onChange={(e) => setEditableData((prev: any) => ({...prev, [fieldName]: e.target.checked }))}
                    className="h-5 w-5 mt-1 text-green-600 border-gray-300 rounded focus:ring-green-500"
                />
            );
        } else {
            content = (
                <>
                    <input
                        type={type}
                        name={fieldName}
                        value={value || ''}
                        onChange={handleInputChange}
                        className={`w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${error ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                    />
                    {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
                </>
            );
        }
    } else {
        content = value ? (typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value) : <span className="text-gray-400 italic">Not provided</span>;
    }

    return (
        <div className="py-3 sm:grid sm:grid-cols-3 sm:gap-4 items-center border-b border-gray-100 last:border-0">
            <dt className="text-sm font-medium text-gray-500">{label}</dt>
            <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2 break-words font-medium">{content}</dd>
        </div>
    );
  };

  const handleDownloadCSV = () => {
    // ... existing CSV logic is fine as it uses local state ...
    const headers = ['Field', 'Value'];
    const rows = Object.entries(editableData).map(([key, value]) => {
      if (key === 'selfie' || key === 'signature' || key === 'latestPayslip') return null; // Skip huge URLs in CSV for clarity
      let formattedValue;
      const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());
      if (typeof value === 'boolean') formattedValue = value ? 'Yes' : 'No';
      else if (typeof value === 'object') formattedValue = JSON.stringify(value);
      else formattedValue = `"${String(value || '').replace(/"/g, '""')}"`;
      return [formattedKey, formattedValue];
    }).filter(Boolean) as string[][]; // Filter out nulls
    
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `application_${(editableData.fullNames || 'data').replace(/\s/g,'_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusColor = (status: string) => {
      switch(status?.toLowerCase()) {
          case 'approved': return 'bg-green-100 text-green-800 border-green-300';
          case 'rejected': return 'bg-red-100 text-red-800 border-red-300';
          case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
          case 'reviewing': return 'bg-blue-100 text-blue-800 border-blue-300';
          default: return 'bg-gray-100 text-gray-800 border-gray-300';
      }
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans pb-12">
      {/* Sticky Admin Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10 border-b border-gray-200">
          <div className="max-w-5xl mx-auto p-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-4 w-full sm:w-auto">
                {onBack && (
                    <button onClick={onBack} className="text-gray-500 hover:bg-gray-100 p-2 rounded-full transition">
                        <i className="fa-solid fa-arrow-left text-lg"></i>
                    </button>
                )}
                <div>
                     <div className="flex items-center gap-3">
                        <h1 className="text-xl font-bold text-gray-900">Application Details</h1>
                         {isEditing ? (
                          <select 
                              name="status" 
                              value={editableData.status || 'New'} 
                              onChange={handleInputChange}
                              className="text-sm font-bold py-1 px-2 rounded border border-blue-300 bg-blue-50 text-blue-800 focus:ring-2 focus:ring-blue-500"
                          >
                              <option value="New">New</option>
                              <option value="Pending">Pending</option>
                              <option value="Reviewing">Reviewing</option>
                              <option value="Approved">Approved</option>
                              <option value="Rejected">Rejected</option>
                          </select>
                      ) : (
                          <span className={`px-3 py-1 text-xs font-extrabold uppercase rounded-full border ${getStatusColor(editableData.status || 'New')}`}>
                              {editableData.status || 'New'}
                          </span>
                      )}
                     </div>
                     <p className="text-sm text-gray-500">{editableData.id}</p>
                </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                {isEditing ? (
                    <>
                        <button onClick={handleCancel} disabled={isSaving} className="px-4 py-2 rounded-lg text-gray-700 font-medium hover:bg-gray-100 transition disabled:opacity-50">
                            Cancel
                        </button>
                        <button onClick={handleSave} disabled={isSaving} className="px-4 py-2 bg-green-600 text-white rounded-lg font-bold hover:bg-green-700 transition shadow-sm flex items-center gap-2 disabled:opacity-50">
                            {isSaving ? <><i className="fa-solid fa-circle-notch fa-spin"></i> Saving...</> : <><i className="fa-solid fa-floppy-disk"></i> Save Changes</>}
                        </button>
                    </>
                ) : (
                    <>
                        <button onClick={handleDownloadCSV} className="px-3 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition flex items-center gap-2 text-sm">
                           <i className="fa-solid fa-file-csv text-green-600"></i> Export CSV
                        </button>
                        <button onClick={() => setIsEditing(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition shadow-sm flex items-center gap-2">
                            <i className="fa-solid fa-pen-to-square"></i> Edit
                        </button>
                    </>
                )}
            </div>
          </div>
          {saveMessage && (
            <div className={`text-center py-2 text-sm font-medium text-white ${saveMessage.type === 'success' ? 'bg-green-500' : 'bg-red-500'}`}>
                {saveMessage.text}
            </div>
          )}
      </div>

      <div className="max-w-5xl mx-auto p-4 md:p-8 grid md:grid-cols-3 gap-6 md:gap-8 items-start">
        
        {/* Main Details Column */}
        <div className="md:col-span-2 space-y-6">
             {/* Loan Summary Card if available */}
             {editableData.loanDetails && (
                <div className="bg-white rounded-xl shadow-sm border border-green-200 overflow-hidden">
                     <div className="bg-green-50 px-6 py-3 border-b border-green-100">
                        <h2 className="text-green-800 font-bold flex items-center gap-2">
                            <i className="fa-solid fa-money-bill-wave"></i> Requested Loan
                        </h2>
                     </div>
                     <div className="p-6 grid grid-cols-3 gap-4 text-center">
                        <div>
                            <p className="text-xs text-gray-500 uppercase font-semibold">Amount</p>
                            <p className="text-lg font-bold text-gray-900">
                                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ZMW' }).format(editableData.loanDetails.amount)}
                            </p>
                        </div>
                         <div>
                            <p className="text-xs text-gray-500 uppercase font-semibold">Duration</p>
                            <p className="text-lg font-bold text-gray-900">{editableData.loanDetails.months} Months</p>
                        </div>
                         <div>
                            <p className="text-xs text-gray-500 uppercase font-semibold">Installment</p>
                            <p className="text-lg font-bold text-green-600">
                                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'ZMW' }).format(editableData.loanDetails.monthlyPayment)}
                            </p>
                        </div>
                     </div>
                </div>
            )}

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                    <h2 className="text-gray-800 font-bold">Personal Information</h2>
                </div>
                <div className="p-6">
                    <dl>
                        {renderField("Full Name", "fullNames")}
                        {renderField("NRC Number", "nrc")}
                        {renderField("Phone Number", "phone", "tel")}
                        {renderField("Email Address", "email", "email")}
                        {renderField("Date Applied", "dateOfApplication", "date")}
                        {renderField("Loan Purpose", "loanPurpose")}
                    </dl>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                    <h2 className="text-gray-800 font-bold">Employment Details</h2>
                </div>
                <div className="p-6">
                    <dl>
                        {renderField("Employer", "employer")}
                        {renderField("Employee #", "employeeNumber")}
                        {renderField("Terms", "employmentTerms", "radio")}
                        {renderField("Work Address", "employmentAddress")}
                    </dl>
                </div>
            </div>

             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                    <h2 className="text-gray-800 font-bold">Bank Details</h2>
                </div>
                <div className="p-6">
                    <dl>
                        {renderField("Bank Name", "bankName")}
                        {renderField("Branch", "branchName")}
                        {renderField("Account No.", "accountNumber")}
                    </dl>
                </div>
            </div>
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                    <h2 className="text-gray-800 font-bold">Next of Kin</h2>
                </div>
                <div className="p-6">
                    <dl>
                        {renderField("Name", "kinFullNames")}
                        {renderField("Relationship", "kinRelationship")}
                        {renderField("Phone", "kinPhone", "tel")}
                        {renderField("Address", "kinResidentialAddress")}
                    </dl>
                </div>
            </div>
        </div>

        {/* Sidebar Column for Media/Docs */}
        <div className="space-y-6">
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b border-gray-200 font-bold text-gray-800">
                    Verification Documents
                </div>
                <div className="p-6 space-y-6">
                    <div>
                        <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Latest Payslip</h3>
                        {editableData.latestPayslip ? (
                             <a 
                                href={editableData.latestPayslip} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="flex items-center justify-between p-3 bg-blue-50 text-blue-700 rounded-lg border border-blue-100 hover:bg-blue-100 transition group"
                            >
                                <div className="flex items-center gap-3">
                                    <i className="fa-solid fa-file-pdf text-2xl"></i>
                                    <span className="font-medium">View Payslip</span>
                                </div>
                                <i className="fa-solid fa-external-link-alt group-hover:translate-x-1 transition-transform"></i>
                            </a>
                        ) : (
                            <div className="p-3 bg-red-50 text-red-600 rounded-lg text-sm font-medium flex items-center gap-2">
                                <i className="fa-solid fa-circle-xmark"></i> Not Uploaded
                            </div>
                        )}
                    </div>

                    <div>
                         <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Client Selfie</h3>
                         {editableData.selfie ? (
                             <div className="rounded-lg overflow-hidden border border-gray-200 shadow-sm">
                                <a href={editableData.selfie} target="_blank" rel="noopener noreferrer">
                                     <img src={editableData.selfie} alt="Client Selfie" className="w-full h-auto hover:opacity-90 transition" />
                                </a>
                             </div>
                         ) : (
                              <div className="h-32 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
                                  <i className="fa-solid fa-image fa-2x"></i>
                              </div>
                         )}
                    </div>

                     <div>
                         <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Signature</h3>
                         <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 flex flex-col gap-2">
                             {editableData.signature ? (
                                 <img src={editableData.signature} alt="Signature" className="max-h-16 object-contain mx-auto" />
                             ) : (
                                 <p className="text-center text-gray-400 italic">Missing</p>
                             )}
                              <div className="pt-2 border-t border-gray-200 mt-2 flex justify-between items-center text-sm">
                                 <span className="text-gray-500">Agreed to Terms?</span>
                                 <span className={`font-bold ${editableData.declarationAgreed ? 'text-green-600' : 'text-red-600'}`}>
                                     {editableData.declarationAgreed ? 'YES' : 'NO'}
                                 </span>
                             </div>
                         </div>
                    </div>
                </div>
            </div>

            {/* Metadata Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 text-xs text-gray-500 space-y-2">
                 <p><span className="font-semibold">Submission ID:</span> <span className="font-mono select-all">{editableData.id}</span></p>
                 <p><span className="font-semibold">Received:</span> {new Date(editableData.submittedAt).toLocaleString()}</p>
                 {editableData.userAgent && (
                     <p className="truncate" title={editableData.userAgent}><span className="font-semibold">Device:</span> {editableData.userAgent}</p>
                 )}
            </div>
        </div>
      </div>
      
      {/* Chatbot floating at bottom right */}
      <AdminChatbot applicationData={editableData} />
    </div>
  );
};

export default AdminView;